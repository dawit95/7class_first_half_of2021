package com.ssafy.hw.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.hw.model.dto.Product;
import com.ssafy.hw.model.mapper.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<Product> selectAll() throws Exception {
		System.out.println(1);
		return sqlSession.getMapper(ProductRepo.class).selectAll();
	}

	@Override
	public Product select(String id) throws Exception {
		return sqlSession.getMapper(ProductRepo.class).select(id);
	}

	@Override
	public void insert(Product product) throws Exception {
		if(product.getId() == null)
			throw new Exception();
		sqlSession.getMapper(ProductRepo.class).insert(product);
	}

	@Override
	public void update(Product product) throws Exception {
		sqlSession.getMapper(ProductRepo.class).update(product);
	}

	@Override
	public void delete(String id) throws Exception {
		sqlSession.getMapper(ProductRepo.class).delete(id);
	}

}
