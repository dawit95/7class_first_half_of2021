package com.ssafy.hw.model.service;

import java.util.List;

import com.ssafy.hw.model.dto.Product;

public interface ProductService {

	public List<Product> selectAll() throws Exception;

	public Product select(String id) throws Exception;

	public void insert(Product product) throws Exception;

	public void update(Product product) throws Exception;

	public void delete(String id) throws Exception;

}
