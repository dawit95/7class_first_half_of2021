package com.ssafy.hw.model.mapper;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.hw.model.dto.Product;

public interface ProductRepo {

	public List<Product> selectAll() throws SQLException;

	public Product select(String id) throws SQLException;

	public void insert(Product product) throws SQLException;

	public void update(Product product) throws SQLException;

	public void delete(String id) throws SQLException;
}
