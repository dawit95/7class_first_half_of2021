import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class 키순서_5643 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int test = Integer.parseInt(br.readLine().trim());
		for (int t = 1; t <= test; t++) {
			int answer = 0;
			int n = Integer.parseInt(br.readLine().trim());
			int m = Integer.parseInt(br.readLine().trim());
			int[][] relationship = new int[n][n];
			for (int i = 0; i < m; i++) {
				String[] input = br.readLine().trim().split(" ");
				int lose = Integer.parseInt(input[0])-1;
				int win = Integer.parseInt(input[1])-1;
				relationship[win][lose] = 1;
				relationship[lose][win] = -1;
			}
			floydWarshall(relationship, n);
			for (int i = 0; i < n; i++) {
				int cnt = 0;
				for (int j = 0; j < n; j++) {
					if (relationship[i][j] == 0) {
						cnt++;
					}
				}
				if (cnt==1)
					answer++;
			}
			System.out.println("#" + t + " " + answer);
		}
	}

	private static void floydWarshall(int[][] graph, int n) {

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (graph[i][j] == 0) {
					for (int m = 0; m < n; m++) {
						if (graph[j][m] == -1 && graph[i][m] == 1) {
							graph[i][j] = 1;
							graph[j][i] = -1;
						} else if (graph[j][m] == 1 && graph[i][m] == -1) {
							graph[i][j] = -1;
							graph[j][i] = 1;

						}
					}
				}
			}

		}

	}
}
