package com.hw.servlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.hw.member.dto.MemberDto;
import com.hw.product.dto.ProductDto;

@WebServlet("/main")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String act = request.getParameter("act");
		if ("login".equals(act)) {
			login(request, response);
		} else if ("registration".equals(act)) {
			registration(request,response);
		} else if ("addProduct".equals(act)) {
			addProduct(request,response);
		} else if ("lastProduct".equals(act)) {
			lastProduct(request,response);
		}
	}

	private void lastProduct(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String root = request.getContextPath();
		response.sendRedirect(root + "/view/lastProduct.jsp");
	}

	private void addProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String root = request.getContextPath();
		String productName = request.getParameter("productName");
		String productPrice = request.getParameter("productPrice");
		String productDescription = request.getParameter("productDescription");

		ProductDto productDto = new ProductDto("1008", productName, productPrice, productDescription);
		String cookieStr = productDto.toString();
		cookieStr = URLEncoder.encode(cookieStr, "UTF-8");
		System.out.println(cookieStr);
		
		//등록 Cookie
		Cookie cookie = new Cookie("num","1008");
		cookie.setPath(root+"/view/lastProduct.jsp");
		//60초*60분*24시간*365일*40년
		cookie.setMaxAge(60*60*24*5);
		response.addCookie(cookie);
		
		productName = URLEncoder.encode(productName, "UTF-8");
		Cookie cookie1 = new Cookie("productName",productName);
		cookie1.setPath(root+"/view/lastProduct.jsp");
		cookie1.setMaxAge(60*60*24*5);
		response.addCookie(cookie1);
		productPrice = URLEncoder.encode(productPrice, "UTF-8");
		Cookie cookie2 = new Cookie("productPrice",productPrice);
		cookie2.setPath(root+"/view/lastProduct.jsp");
		cookie2.setMaxAge(60*60*24*5);
		response.addCookie(cookie2);
		productDescription = URLEncoder.encode(productDescription, "UTF-8");
		Cookie cookie3 = new Cookie("productDescription",productDescription);
		cookie3.setPath(root+"/view/lastProduct.jsp");
		cookie3.setMaxAge(60*60*24*5);
		response.addCookie(cookie3);
		
		
		response.sendRedirect(root + "/index.jsp");
	}

	private void registration(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String root = request.getContextPath();
		response.sendRedirect(root + "/product/register.jsp");
	}

	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String id = request.getParameter("userid");
		String pass = request.getParameter("userpwd");
		
		MemberDto memberDto = new MemberDto();
		memberDto.setUserId(id);
		memberDto.setUserPwd(pass);
		
		HttpSession session = request.getSession();
		session.setAttribute("userinfo", memberDto);
//		request.setAttribute("userinfo", memberDto);
		RequestDispatcher disp = request.getRequestDispatcher(path);
		disp.forward(request, response);
	}

	
//
//	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
//		HttpSession session = request.getSession();
////		session.removeAttribute("userinfo");
//		//session안에 있는 모든것을 삭제.
//		session.invalidate();
//		
//		response.sendRedirect(request.getContextPath() + "/index.jsp");
//	}
//
//	private void login(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
//		String root = request.getContextPath();
//
//		String id = request.getParameter("userid");
//		String pass = request.getParameter("userpwd");
//
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		MemberDto memberDto = null;
//		try {
//			conn = DriverManager.getConnection(
//					"jdbc:mysql://127.0.0.1:3306/ssafyweb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8",
//					"ssafy", "ssafy");
//			String sql = "select username, email \n";
//			sql += "from ssafy_member \n";
//			sql += "where userid = ? and userpwd = ?";
//			pstmt = conn.prepareStatement(sql);
//			int idx = 0;
//			pstmt.setString(++idx, id);
//			pstmt.setString(++idx, pass);
//			rs = pstmt.executeQuery();
//			if (rs.next()) {
//				memberDto = new MemberDto();
//				memberDto.setUserName(rs.getString("username"));
//				memberDto.setEmail(rs.getString("email"));
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			try {
//				if (rs != null)
//					rs.close();
//				if (pstmt != null)
//					pstmt.close();
//				if (conn != null)
//					conn.close();
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		}
//		
//		System.out.println("sql 성공 여부 cnt값 : ");
//
//		String path = "/index.jsp";
//		if (memberDto != null) { // 성공
////			session setting
//			HttpSession session = request.getSession();
//			session.setAttribute("userinfo", memberDto);
////			request.setAttribute("userinfo", memberDto);
////			response.sendRedirect(root + "/index.jsp");
//			
////			Cookie setting
//			String idsv = request.getParameter("idsave");
//			if( idsv != null) {
//				Cookie cookie = new Cookie("save_id",id);
//				cookie.setPath(root);
//				//60초*60분*24시간*365일*40년
//				cookie.setMaxAge(60*60*24*5);
//				
//				//서버에서 만든 쿠키를 client에게 전해주기
//				response.addCookie(cookie);
//			} else {	// id save X
//				Cookie cookies[] = request.getCookies();
//				if(cookies != null) {
//					for (Cookie cookie : cookies) {
//						if(cookie.getName().equals("save_id")) {
//							cookie.setMaxAge(0);
//							response.addCookie(cookie);
//							break;
//						}
//					}
//				}
//			}
//			
//		} else {
//			request.setAttribute("msg", "가입하지 않은 아이디이거나, 잘못된 비밀번호입니다.");
////			response.sendRedirect(root + "/user/login.jsp");
//			path = "/user/login.jsp";
//		}
//		
//		// 내 경로 안에서 이동할수 있음.
//		RequestDispatcher disp = request.getRequestDispatcher(path);
//		disp.forward(request, response);
//
//	}

}
