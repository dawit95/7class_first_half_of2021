package com.ssafy.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class hwalgo08_����_7��_�ִ��� {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine().trim(), " ");
		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int r = Integer.parseInt(st.nextToken());
		int[][] arr = new int[n][m];
		// �Է�
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine().trim(), " ");
			for (int j = 0; j < m; j++) {
				arr[i][j] = Integer.parseInt(st.nextToken());
			}
		}
		String[] play = br.readLine().split(" ");
		for (int i = 0; i < r; i++) {
			switch (play[i]) {
			case "1":
				arr = play1(arr, n, m);
				break;
			case "2":
				arr = play2(arr, n, m);
				break;
			case "3":
				arr = play3(arr, n, m);
				break;
			case "4":
				arr = play4(arr, n, m);
				break;
			case "5":
				arr = play5(arr, n, m);
				break;
			case "6":
				arr = play6(arr, n, m);
				break;
			}
			n = arr.length;
			m = arr[0].length;
		}
		// ���
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				sb.append(arr[i][j]).append(" ");
			}
			sb.append("\n");
		}
		System.out.println(sb.toString());

	}

	private static int[][] play1(int[][] arr, int n, int m) {
		int[][] tmp = new int[n][m];
		for (int i = 0; i < n; i++) {
			tmp[i] = arr[n - i - 1];
		}
		return tmp;
	}

	private static int[][] play2(int[][] arr, int n, int m) {
		int[][] tmp = new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				tmp[i][j] = arr[i][m - j - 1];
			}
		}
		return tmp;
	}

	private static int[][] play3(int[][] arr, int n, int m) {
		int[][] tmp = new int[m][n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				tmp[j][n - i - 1] = arr[i][j];
			}
		}
		return tmp;
	}

	private static int[][] play4(int[][] arr, int n, int m) {
		int[][] tmp = new int[m][n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				tmp[m - j - 1][i] = arr[i][j];
			}
		}
		return tmp;
	}

	private static int[][] play5(int[][] arr, int n, int m) {
		int[][] tmp = new int[n][m];
		int[] dx = { 0, 1, 1, 0, 0 };
		int[] dy = { 0, 0, 1, 1, 0 };
		for (int part = 0; part < 4; part++) {
			for (int i = 0; i < (n / 2); i++) {
				for (int j = 0; j < (m / 2); j++) {
					tmp[i + dy[part + 1] * (n / 2)][j + dx[part + 1] * (m / 2)] = arr[i + dy[part] * (n / 2)][j
							+ dx[part] * (m / 2)];
				}
			}
		}
		return tmp;
	}

	private static int[][] play6(int[][] arr, int n, int m) {
		int[][] tmp = new int[n][m];
		int[] dx = { 0, 1, 1, 0, 0 };
		int[] dy = { 0, 0, 1, 1, 0 };
		for (int part = 0; part < 4; part++) {
			for (int i = 0; i < (n / 2); i++) {
				for (int j = 0; j < (m / 2); j++) {
					tmp[i + dy[part] * (n / 2)][j + dx[part] * (m / 2)] = arr[i + dy[part + 1] * (n / 2)][j
							+ dx[part + 1] * (m / 2)];
				}
			}
		}
		return tmp;
	}

}
