package com.ssafy.hwalgo17;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.StringTokenizer;

public class hwalgo17_서울_7반_최다윗 {

	static int N;
	static int parents[];
	static int cost[];
	static boolean[] child;

	static void make() { // 크기가 1인 단위 집합을 만든다.
		for (int i = 0; i < N; i++) {
			parents[i] = i;
		}
	}

	static int findSet(int a) {
		if (parents[a] == a)
			return a;
//		return findSet(parents[a]);	// path compression 전
		return parents[a] = findSet(parents[a]); // path compression 후
	}

	// 합쳐졌는지 확인하기 위한 리턴값
	static boolean union(int a, int b) {
		int aRoot = findSet(a);
		int bRoot = findSet(b);

		if (aRoot == bRoot) {
			return false;
		}

		// bRoot의 부모를 aRoot로 만들어 한 조직으로 연합
		if (cost[aRoot] > cost[bRoot]) {
			parents[aRoot] = bRoot;
			child[aRoot] = true;
		} else {
			parents[bRoot] = aRoot;
			child[bRoot] = true;
		}
		return true;
	}

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine().trim(), " ");
		N = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		N++;
		parents = new int[N];
		cost = new int[N];
		child = new boolean[N];

		make();

		st = new StringTokenizer(br.readLine().trim(), " ");
		for (int i = 1; i < N; i++) {
			cost[i] = Integer.parseInt(st.nextToken());
		}

		for (int i = 0; i < m; i++) {
			st = new StringTokenizer(br.readLine().trim(), " ");
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			union(a, b);
		}

		int cnt = 0;
		HashSet<Integer> set = new HashSet<Integer>();
		for (int i = 1; i < N; i++) {
			if (child[i])
				continue;
			if (!set.contains(parents[i])) {
				set.add(parents[i]);
				cnt += cost[i];
			}
		}

		if (k >= cnt) {
			System.out.println(cnt);
		} else {
			System.out.println("Oh no");
		}

	}
}
