package com.ssafy.hwjava06;

public class ProductMgr {

	private final static int MAX_SIZE = 100;
	private Product[] products = new Product[MAX_SIZE];
	private int size = 0;

	private static ProductMgr instance;

	private ProductMgr() {
		super();
		this.size = 0;
	}

	public static ProductMgr getInstance() {
		if (instance == null) {
			instance = new ProductMgr();
		}
		return instance;
	}

	public boolean add(Product p) {
		if (size < 100) {
			products[size] = p;
			size++;
			return true;
		} else {
			return false;
		}
	}

	public Product[] list() {
		Product[] newProducts = new Product[size];
		for (int i = 0; i < size; i++) {
			newProducts[i] = products[i];
		}
		return newProducts;
	}
	
	public Product list(int num) {
		for (int i = 0; i < size; i++) {
			if (products[i].getSerialNumber() == num) {
				return products[i];
			}
		}
		return null;
	}

	//상품명 부분 검색 가능
	public Product[] list(String subName) {
		ProductMgr pm = new ProductMgr();
		String tmp = subName.trim();
		for (int i = 0; i < size; i++) {
			if(products[i].getName().contains(tmp))
				pm.add(products[i]);
		}
		return pm.list();
	}
	
	public Product[] TVList() {
		ProductMgr pm = new ProductMgr();
		for (int i = 0; i < size; i++) {
			if (products[i] instanceof TV) {
				pm.add(products[i]);
			}
		}
		return pm.list();
	}
	
	public Product[] RefrigeratorList() {
		ProductMgr pm = new ProductMgr();
		for (int i = 0; i < size; i++) {
			if (products[i] instanceof Refrigerator) {
				pm.add(products[i]);
			}
		}
		return pm.list();
	}

	public void delete(int num) {
		for (int i = 0; i < size; i++) {
			if (products[i].getSerialNumber() == num) {
				products[i] = products[size - 1];
				size--;
			}
		}
	}

	public int totalPrice() {
		int totalPrice = 0;
		for (int i = 0; i < size; i++) {
			totalPrice += products[i].getPrice() * products[i].getQuantity();
		}
		return totalPrice;

	}

}
