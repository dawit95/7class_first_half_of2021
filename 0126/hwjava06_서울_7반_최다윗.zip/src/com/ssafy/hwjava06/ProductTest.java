package com.ssafy.hwjava06;

public class ProductTest {

	public static void main(String[] args) {
		ProductMgr productMgr = ProductMgr.getInstance();

		System.out.println("*********************상품목록*********************");
		Product[] products = productMgr.list();
		if(products.length != 0)
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.out.println("제품이 없습니다.");
		
		System.out.println("*********************상품 저장!!!*********************");
		boolean check = true;
		check = productMgr.add(new Refrigerator(123,"LG 냉장고",500000,20));
		if(!check) System.err.println("저장공간이 부족합니다!");
		check = productMgr.add(new TV(456,"LG TV",800000,20));
		if(!check) System.err.println("저장공간이 부족합니다!");
		check = productMgr.add(new TV(457,"Google TV",400000,20));
		if(!check) System.err.println("저장공간이 부족합니다!");
		check = productMgr.add(new Refrigerator(1234,"삼성 냉장고",400000,20));
		if(!check) System.err.println("저장공간이 부족합니다!");
		check = productMgr.add(new TV(4567,"삼성 TV",900000,20));
		if(!check) System.err.println("저장공간이 부족합니다!");
		check = productMgr.add(new Refrigerator(7890,"대우 냉장고",450000,20));
		if(!check) System.err.println("저장공간이 부족합니다!");
		
		System.out.println("*********************상품목록*********************");
		products = productMgr.list();
		if(products.length != 0)
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.err.println("제품이 없습니다.");
		
		System.out.println("*********************상품 조회:4567*********************");
		Product p = productMgr.list(4567);
		if(p != null)
			System.out.println(p);
		else
			System.err.println("제품이 없습니다.");
		
		System.out.println("*********************상품이름으로 조회:'삼'*********************");
		products = productMgr.list("삼");
		if(products.length != 0)
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.err.println("조회하신 이름의 제품이 없습니다.");
		
		System.out.println("*********************TV상품만 조회*********************");
		products = productMgr.TVList();
		if(products.length != 0)
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.err.println("제품이 없습니다.");
		
		System.out.println("*********************냉장고 상품만 조회*********************");
		products = productMgr.RefrigeratorList();
		if(products.length != 0)
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.err.println("제품이 없습니다.");

		System.out.println("*********************상품 제거:457*********************");
		productMgr.delete(789);
		
		System.out.println("*********************상품목록*********************");
		products = productMgr.list();
		if(products.length != 0)
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.err.println("제품이 없습니다.");
		
		System.out.println("*********************등록된 상품 총 금액*********************");
		int totalPrice = productMgr.totalPrice();
		System.out.println("등록된 제품의 총 금액 : "+ totalPrice+"원");
	}

}
