package com.java.first;

import java.util.Scanner;

//Scanner, if 사용
public class CheckPoint {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int weight = input.nextInt();
		int height = input.nextInt();
		input.nextLine();
		input.close();
		
		int result = weight + 100 - height;
		System.out.println("비만수치는 " + result + "입니다.");

		if(result>0) {
			System.out.println("당신은 비만이군요");
		}else {
			System.out.println("당신은 정상체중입니다.");
		}
	}
}
