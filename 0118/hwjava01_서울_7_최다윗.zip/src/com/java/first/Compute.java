package com.java.first;

import java.util.Scanner;

// Scanner사용
public class Compute {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int firstNum = input.nextInt();
		int secondNum = input.nextInt();
		input.nextLine();
		System.out.println("곱="+(firstNum*secondNum));
		System.out.println("몫="+(firstNum/secondNum));
		input.close();
	}
}
