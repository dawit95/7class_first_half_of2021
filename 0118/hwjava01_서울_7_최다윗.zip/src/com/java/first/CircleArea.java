package com.java.first;

//형식지정자 사용
public class CircleArea {
	
	public static void main(String[] args) {
		int radius = 5;
		final double PI = 3.14;
		double result = radius*radius*PI;
		System.out.printf("반지름이 %dCm인 원의 넓이는 %.1fCm2입니다.",radius,result);
	}
}
