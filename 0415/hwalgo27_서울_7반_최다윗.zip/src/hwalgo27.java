import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class hwalgo27 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] input = br.readLine().trim().split(" ");
		int n = Integer.parseInt(input[0]);
		int d = Integer.parseInt(input[1]);
		int k = Integer.parseInt(input[2]);
		int c = Integer.parseInt(input[3]);
		Queue<Integer> queue = new LinkedList<Integer>();
		int[] remember = new int[k];
		int[] map = new int[d + 1];
		int cnt = 0;

		// k개 먹기
		for (int i = 0; i < k; i++) {
			int now = Integer.parseInt(br.readLine().trim());
			queue.offer(now);
			cnt += ++map[now] == 1 ? 1 : 0;
			remember[i] = now;
		}
		// 쿠폰초밥 먹기
		map[c]++;
		if (map[c] == 1) {
			cnt++;
		}

		int max = cnt;
		int out;
		int now;
		for (int i = k; i < n; i++) {
			now = Integer.parseInt(br.readLine().trim());
			out = queue.poll();
			queue.offer(now);
			if (now == out)
				continue;
			cnt -= --map[out] == 0 ? 1 : 0;
			cnt += ++map[now] == 1 ? 1 : 0;
			max = Math.max(max, cnt);
		}

		for (int i = 0; i < k; i++) {
			now = remember[i];
			out = queue.poll();
			queue.offer(now);
			if (now == out)
				continue;
			cnt -= --map[out] == 0 ? 1 : 0;
			cnt += ++map[now] == 1 ? 1 : 0;
			max = Math.max(max, cnt);
		}
		System.out.println(max);
	}

}
