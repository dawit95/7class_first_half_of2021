<template lang="">
  <div>
    <div class="container text-center border">
      <h2><a href=""> 사원 등록</a></h2>
    </div>
    <br />
    <div class="form-group form-inline">
      <label for="emp-name" class="col-sm-3 control-label">이름</label>
      <input v-model="emp.name" id="emp-name" class="col-sm-7 form-control" type="text" />
    </div>
    <div class="form-group form-inline">
      <label for="emp-email" class="col-sm-3 control-label">이메일</label>
      <input v-model="emp.email" id="emp-email" class="col-sm-7 form-control" type="text" />
    </div>
    <div class="form-group form-inline">
      <label for="emp-join" class="col-sm-3 control-label">고용일</label>
      <input v-model="emp.hire" id="emp-join" class="col-sm-7 form-control" type="date" />
    </div>
    <div class="form-group form-inline">
      <label for="emp-manager" class="col-sm-3 control-label">관리자</label>
      <select v-model="emp.manager" id="emp-manager" class="col-sm-7 form-control">
        <option value="">관리자</option>
        <option value="사장">사장</option>
        <option value="기획부장">기획부장</option>
        <option value="영업부장">영업부장</option>
        <option value="총무부장">총무부장</option>
        <option value="인사부장">인사부장</option>
        <option value="과장">과장</option>
        <option value="영업대표이사">영업대표이사</option>
        <option value="사원">사원</option>
      </select>
    </div>
    <div class="form-group form-inline">
      <label for="emp-hire" class="col-sm-3 control-label">직책</label>
      <select v-model="emp.title" id="emp-hire" class="col-sm-7 form-control">
        <option value="">직책</option>
        <option value="사장">사장</option>
        <option value="기획부장">기획부장</option>
        <option value="영업부장">영업부장</option>
        <option value="총무부장">총무부장</option>
        <option value="인사부장">인사부장</option>
        <option value="과장">과장</option>
        <option value="영업대표이사">영업대표이사</option>
        <option value="사원">사원</option>
      </select>
    </div>
    <div class="form-group form-inline">
      <label for="emp-dept" class="col-sm-3 control-label">부서</label>
      <input v-model="emp.dept" id="emp-dept" class="col-sm-7 form-control" type="text" />
    </div>
    <div class="form-group form-inline">
      <label for="emp-salary" class="col-sm-3 control-label">월급</label>
      <input v-model="emp.salary" id="emp-salary" class="col-sm-7 form-control" type="text" />
    </div>
    <div class="form-group form-inline">
      <label for="emp-commission" class="col-sm-3 control-label">커미션</label>
      <input
        v-model="emp.commission"
        id="emp-commission"
        class="col-sm-7 form-control"
        type="text"
      />
    </div>
    <!-- </from> -->
    <br />
    <div class="text-center">
      <button @click="btnClick" class="btn btn-primary">사원 추가</button>
    </div>
  </div>
</template>
<script>
import http from '@/util/http-common';

export default {
  name: 'empsregist',
  data() {
    return {
      emp: {
        id: '',
        name: '',
        email: '',
        hire: '',
        manager: '',
        title: '',
        dept: '',
        salary: '',
        commission: '',
      },
      emps: [],
    };
  },
  methods: {
    btnClick: function () {
      if (this.emp.name == null || this.emp.name == '') {
        alert('이름은 필수 입력사항입니다.');
        return;
      } else if (this.emp.title == null || this.emp.title == '') {
        alert('직책 필수 입력사항입니다.');
        return;
      } else if (this.emp.dept == null || this.emp.dept == '') {
        alert('부서은 필수 입력사항입니다.');
        return;
      } else if (this.emp.salary == null || this.emp.salary == '') {
        alert('연봉은 필수 입력사항입니다.');
        return;
      }

      http
        .post('/employee', {
          name: this.name,
          email: this.email,
          hire: this.hire,
          manager: this.manager,
          title: this.title,
          dept: this.dept,
          salary: this.salary,
          commission: this.commission,
        })
        .then(({ data }) => {
          let msg = '등록 처리시 문제가 발생했습니다.';
          if (data === 'success') {
            msg = '등록이 완료되었습니다.';
          }
          alert(msg);
          this.$router.push('/empslist');
        })
        .catch(() => {
          alert('등록 처리시 에러가 발생했습니다.');
        });
    },
  },
};
</script>
<style lang=""></style>
