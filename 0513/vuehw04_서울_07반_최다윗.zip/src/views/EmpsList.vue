<template>
  <div>
    <h2 align="center">사원목록</h2>
    <div class="container text-center mb-2 p-2">
      <label for="searchword">사원명 검색</label>
      <input id="searchword" type="text" v-model="searchTitle" /><button @click="search">
        검색
      </button>
    </div>
    <table class="table table-hover table-bordered">
      <colgroup>
        <col :style="{ width: '25%' }" />
        <col :style="{ width: '15%' }" />
        <col :style="{ width: '20%' }" />
        <col :style="{ width: '20%' }" />
        <col :style="{ width: '25%' }" />
      </colgroup>
      <tr>
        <th class="text-center">사원 아이디</th>
        <th class="text-center">사원명</th>
        <th class="text-center">부서</th>
        <th class="text-center">직책</th>
        <th class="text-center">연봉</th>
      </tr>
      <list-row
        v-for="(emp, index) in emps"
        :key="`${index}_items`"
        :id="emp.id"
        :name="emp.name"
        :dept="emp.dept"
        :title="emp.title"
        :salary="emp.salary"
      />
    </table>
    <div class="text-right">
      <button class="btn btn-primary" @click="movePage">등록</button>
    </div>
  </div>
</template>
<script>
import http from '@/util/http-common';
import ListRow from '@/components/Row.vue';

export default {
  name: 'empslist',
  components: {
    ListRow,
  },
  data: function () {
    return {
      searchTitle: '',
      emps: [],
    };
  },
  created() {
    http
      .get('/employee')
      .then(({ data }) => {
        this.emps = data;
      })
      .catch(() => {
        alert('에러가 발생했습니다.');
      });
  },
  methods: {
    movePage() {
      this.$router.push('/empsregist');
    },
    search() {
      if (this.searchTitle == '') {
        http
          .get('/employee')
          .then(({ data }) => {
            this.emps = data;
          })
          .catch(() => {
            alert('에러가 발생했습니다.');
          });
      } else {
        http
          .get(`/employee/search/${this.searchTitle}`)
          .then(({ data }) => {
            this.emps = data;
          })
          .catch(() => {
            alert('검색 중에 에러가 발생했습니다.');
          });
      }
    },
  },
};
</script>
<style lang=""></style>
