<template>
  <div>
    <h2 align="center">사원 정보</h2>
    <br />
    <div align="center">
      <detail
        :id="emp.id"
        :name="emp.name"
        :dept="emp.dept"
        :title="emp.title"
        :salary="emp.salary"
      />
    </div>
  </div>
</template>
<script>
import http from '@/util/http-common';
import Detail from '@/components/Detail.vue';

export default {
  name: 'empdetail',
  components: {
    Detail,
  },
  data: function () {
    return {
      emp: {},
      param: '',
    };
  },
  created() {
    http.get(`/employee/${this.$route.query.id}`).then(({ data }) => {
      this.emp = data;
    });
  },
};
</script>
<style lang=""></style>
