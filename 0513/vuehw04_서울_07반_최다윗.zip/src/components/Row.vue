<template>
  <tr>
    <td>{{ id }}</td>
    <td>
      <router-link :to="`/empdetail?id=${id}`">{{ name }}</router-link>
    </td>
    <td>{{ dept }}</td>
    <td>{{ title }}</td>
    <td>{{ salary }}</td>
  </tr>
</template>

<script>
export default {
  name: 'row',
  props: {
    id: { type: Number },
    name: { type: String },
    dept: { type: String },
    title: { type: String },
    salary: { type: String },
  },
};
</script>
