import Vue from 'vue';
import VueRouter from 'vue-router';
import Index from '@/views/index.vue';
import EmpsList from '@/views/EmpsList.vue';
import EmpDetail from '@/views/EmpDetail.vue';
import EmpsRegist from '@/views/EmpsRegist.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'index',
    component: Index,
  },
  {
    path: '/empsregist',
    name: 'empsregist',
    component: EmpsRegist,
  },
  {
    path: '/empdetail',
    name: 'empdetail',
    component: EmpDetail,
  },
  {
    path: '/empslist',
    name: 'empslist',
    component: EmpsList,
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
