import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class 이항계수구하기_3238 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int testcase = Integer.parseInt(br.readLine().trim());

		for (int t = 1; t <= testcase; t++) {
			String[] tmp = br.readLine().trim().split(" ");
			long n = Long.parseLong(tmp[0]);
			long r = Long.parseLong(tmp[1]);
			int p = Integer.parseInt(tmp[2]);

			System.out.println("#" + t + " " + nCr(n, r, p));
		}
	}

	private static long nCr(long N, long R, int P) {
		if (R == N || R == 0)
			return 1;
		if (R == 1 || R + 1 == N)
			return N;

		long res, F[] = new long[P];
		res = F[0] = 1;
		for (int i = 1; i < P; i++)
			F[i] = i * F[i - 1] % P;

		while (N != 0 || R != 0) {

			int n = (int) (N % P);
			int r = (int) (R % P);

			if (n < r) {
				res = 0;
				break;
			}

			res = res * F[n] % P;
			res = res * pow((F[n - r] * F[r]) % P, P - 2, P) % P;

			N /= P;
			R /= P;

		}

		return res;
	}

	public static long pow(long x, int y, int P) {
		long res = 1;

		while (y > 0) {
			if ((y & 1) == 1)
				res = res * x % P;
			y >>= 1;
			x = x * x % P;
		}

		return res;
	}

}
