package test;

public class HW_java01 {
	public static void main(String[] args) {
		
	}
}
