package com.ssafy.hwalgo15;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.regex.Pattern;

public class hwalgo15_서울_7반_최다윗 {

	static String[] input;
	static int l, c;
	static StringBuilder sb;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader((System.in)));
		String[] str = br.readLine().trim().split(" ");
		l = Integer.parseInt(str[0]);
		c = Integer.parseInt(str[1]);
		input = new String[c];

		str = br.readLine().trim().split(" ");
		for (int i = 0; i < c; i++) {
			input[i] = str[i];
		}
		Arrays.sort(input);
		sb = new StringBuilder();
		combination(0, new String[l], 0);
		System.out.println(sb.toString());
	}

	private static void combination(int toSelect, String[] selected, int startIdx) {

		if (toSelect == l) {
			int aeiouCnt = 0;
			int etcCnt = 0;
			StringBuilder tmp = new StringBuilder();
			for (int i = 0; i < l; i++) {
				if(Pattern.matches("[aeiou]", selected[i])){
					aeiouCnt++;
				}else {
					etcCnt++;
				}
				tmp.append(selected[i]);
			}
			if(aeiouCnt>=1&&etcCnt>=2) {
				sb.append(tmp.toString()).append("\n");
			}
			return;
		}

		for (int i = startIdx; i < c; i++) {
			selected[toSelect] = input[i];
			combination(toSelect + 1, selected, i + 1);
		}
	}

}
