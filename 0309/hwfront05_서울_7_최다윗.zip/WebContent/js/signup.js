$(document).ready(function () {
    console.log($('#password').val());
    $('#btnSignup').click(function () {
        var getMail = RegExp(/^[A-Za-z0-9_\.\-]+@[A-Za-z0-9\-]+\.[A-Za-z0-9\-]+/);
        var getCheck = RegExp(/^[a-zA-Z0-9]{4,20}$/);
        var getCheckpwd = RegExp( /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/);
        var getName = RegExp(/^[가-힣]+$/);

        //아이디 공백 확인
        if ($("#id").val() == "") {
            alert("아이디 입력바람");
            $("#id").focus();
            return false;
        }

        //아이디 유효성검사
        if (!getCheck.test($("#userid").val())) {
            alert("형식에 맞게 입력해주세요");
            $("#userid").val("");
            $("#userid").focus();
            return false;
        }
        //비밀번호 공백 확인
        if ($("#password").val() == "") {
            alert("패스워드 입력바람");
            $("#password").focus();
            return false;
        }

        //아이디 비밀번호 같음 확인
        if ($("#id").val() == $("#password").val()) {
            alert("아이디와 비밀번호가 같습니다");
            $("#password").val("");
            $("#password").focus();
            return false;
        }
        //비밀번호 유효성검사
        if (!getCheckpwd.test($("#password").val())) {
            alert("형식에 맞게 입력해주세요");
            $("#password").val("");
            $("#password").focus();
            return false;
        }
        //이메일 공백 확인 
        if ($("#mail").val() == "") {
            alert("이메일을 입력해주세요");
            $("#mail").focus();
            return false;
        }
        //이메일 유효성 검사 
        if (!getMail.test($("#mail").val())) {
            alert("이메일형식에 맞게 입력해주세요");
            $("#mail").val("");
            $("#mail").focus();
            return false;
        }
        //이름 공백 검사 
        if ($("#name").val() == "") {
            alert("이름을 입력해주세요");
            $("#name").focus();
            return false;
        }
        //이름 유효성 검사 
        if (!getName.test($("#name").val())) {
            alert("이름형식에 맞게 입력해주세요");
            $("#name").val("");
            $("#name").focus();
            return false;
        }
        //지역
        var flag = true;
        $('.form-check-input').each(function (idx, item) {
            if ($(item).is(':checked')) {
                flag = false;
            }
        });
        if (flag) {
            alert("지역을 체크해주세요");
            $('.form-check-input').focus();
            return false;
        }
        //음식 공백 검사 
        if ($("#food").val() == "") {
            alert("이름을 입력해주세요");
            $("#food").focus();
            return false;
        }
        //이름 유효성 검사 
        if (!getName.test($("#food").val())) {
            alert("좋아하는 음식을 입력해주세요");
            $("#food").val("");
            $("#food").focus();
            return false;
        }
        alert("ok!");
    });
});