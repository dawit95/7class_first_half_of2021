$(document).ready(function () {
    $('#submitLogin').click(function () {
         // server에서 넘어온 data
        $.ajax({
            url: '../res/userlist.xml',
            type: 'GET',
            dataType: 'xml',
            success: function (response) {
                checkList(response);
            },
            error: function (xhr, status, msg) {
                console.log('상태값 : ' + status + ' Http에러메시지 : ' + msg);
            },
        });
        
        function checkList(data) {
            console.log($(data).find('user').text()+ '///');
            //입력한 데이터
            var flag = false;
            var userid = $('#userid').val();
            var userpwd = $('#pwd').val();
            $(data).find('user').each(function (idx, item) {
                console.log($(item).find('id').text() + ' ' + userid + '///');
                console.log($(item).find('pwd').text() + ' ' + userpwd + '///');
                if ($(item).find('id').text() == userid && $(item).find('pwd').text()==userpwd) {
                    $('#login').hide();
                    var username = $(item).find('name').text();
                    $('#userNameText').text(username);
                    $('#logout').show();
                    flag = true;
                    return;
                }
            });
            if(!flag)
            alert('틀렸습니다. 다시 입력해주세요!');
        };
    });
    //로그아웃
    $('#btnLogout').click(function () {
        $('#userid').val('');
        $('#pwd').val('');
        $('#logout').hide();
        $('#login').show(); 
    });

});