package com.ssafy.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class hwalgo09_����_7��_�ִ��� {

	static int[] dwarf;
	static boolean masterBreak = false;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		dwarf = new int[9];
		for (int i = 0; i < dwarf.length; i++) {
			dwarf[i] = Integer.parseInt(br.readLine().trim());
		}
		combi(0, new int[7], 0, 0);

	}

	private static void combi(int idx, int[] selected, int start, int sum) {
		if (masterBreak)
			return;
		if (idx == 7) {
			if (sum == 100) {
				for (int i : selected) {
					System.out.println(i);
				}
				masterBreak = true;
			}
			return;
		}

		for (int i = start; i < 9; i++) {
			selected[idx] = dwarf[i];
			combi(idx + 1, selected, i + 1, sum + selected[idx]);
		}
	}
}
