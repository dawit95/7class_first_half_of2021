package com.ssafy.ws.model.service;

import com.ssafy.ws.model.dto.User;

public interface UserService {
	public User select(String id) throws Exception;
}
