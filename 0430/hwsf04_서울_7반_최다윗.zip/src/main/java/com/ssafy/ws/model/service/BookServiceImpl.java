package com.ssafy.ws.model.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.ws.model.dto.Book;
import com.ssafy.ws.model.dto.SearchCondition;
import com.ssafy.ws.model.repo.BookRepo;
import com.ssafy.ws.util.PageNavigation;

/**
 * 빈으로 등록될 수 있도록 @Service를 선언한다.
 *
 */
@Service
public class BookServiceImpl implements BookService {
//	/**
//	 * has a 관계로 사용할 BookRepo 타입의 repo를 선언한다.
//	 */
//	private BookRepo repo;
//	
//	/**
//	 * setter를 통해 BookRepo를 주입받는다.
//	 * @Autowired를 통해 BookRepo 타입의 빈을 주입 받는다.
//	 * @param repo
//	 */
//	@Autowired
//	public void setBookRepo(BookRepo repo) {
//		this.repo = repo;
//	}
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public void insert(Book book) throws SQLException {
		sqlSession.getMapper(BookRepo.class).insert(book);
	}

	@Override
	public void update(Book book) throws SQLException {
		sqlSession.getMapper(BookRepo.class).update(book);
	}

	@Override
	public void delete(String isbn) throws SQLException {
		sqlSession.getMapper(BookRepo.class).delete(isbn);
	}

	@Override
	public Book select(String isbn) throws SQLException {
		return 	sqlSession.getMapper(BookRepo.class).select(isbn);
	}

	@Override
	public List<Book> search(SearchCondition condition) throws SQLException {
		return 	sqlSession.getMapper(BookRepo.class).search(condition);
	}
	
	/**
	 * 리스트에 페이징을 적용하기 위한 메서드
	 * Map에 books를 키로 화면에 표시할 Book 목록을 저장하고
	 * navigation이라는 키로  PageNavigation 객체를 저장해서 반환한다.
	 * PageNavigation을 만들기 위한 정보로 currentPage는 SearchCondition에서 얻어오고 
	 * totalCount는 BookRepo에 새롭게 추가한 메서드를 사용한다.
	 * @param condition
	 * @return
	 */
	@Override
	public Map<String, Object> pagingSearch(SearchCondition condition) throws Exception {
		Map<String, Object> value = new HashMap<String,Object>();
		List<Book> books = search(condition);
		int totalConut = sqlSession.getMapper(BookRepo.class).getTotalSearchCount(condition);
		PageNavigation navigation = new PageNavigation(condition.getCurrentPage(), totalConut);
		value.put("books", books);
		value.put("navigation", navigation);
		return value;
	}

}
