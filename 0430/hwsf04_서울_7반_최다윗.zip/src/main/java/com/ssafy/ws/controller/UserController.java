package com.ssafy.ws.controller;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssafy.ws.model.dto.User;
import com.ssafy.ws.model.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	private Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService userService;
 
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login() {
		return "user/login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(User user, Model model, HttpSession session, HttpServletResponse response) {
		try {
			User user1 = userService.select(user.getId());
			if (user1 != null) {
				if (user1.getPass().equals(user.getPass())) {
					logger.debug("로그인 해야하는디는디");
					session.setAttribute("loginUser", user1);
				}else {
					model.addAttribute("msg", "아이디 또는 비밀번호 확인 후 로그인해 주세요.");									
				}
			}else {
				model.addAttribute("msg", "아이디 또는 비밀번호 확인 후 로그인해 주세요.");				
			}
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("msg", "로그인 중 문제가 발생했습니다.");
			return "error/500";
		}
		return "index";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "index";
	}
}
