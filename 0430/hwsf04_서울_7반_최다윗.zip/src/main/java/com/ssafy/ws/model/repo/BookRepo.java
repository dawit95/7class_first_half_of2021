package com.ssafy.ws.model.repo;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.ws.model.dto.Book;
import com.ssafy.ws.model.dto.SearchCondition;

public interface BookRepo {
	
	public int getTotalSearchCount(SearchCondition condition)throws SQLException;

	public void insert(Book book) throws SQLException;

	public void update(Book book)throws SQLException;

	public void delete(String isbn)throws SQLException;
	
	public Book select(String isbn)throws SQLException;
	
	public List<Book> search(SearchCondition condition)throws SQLException;
}
