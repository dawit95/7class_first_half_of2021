package com.ssafy.ws.model.service;

import java.util.List;
import java.util.Map;

import com.ssafy.ws.model.dto.Book;
import com.ssafy.ws.model.dto.SearchCondition;

public interface BookService {
	
	public Map<String, Object> pagingSearch(SearchCondition condition) throws Exception;
	
	public void insert(Book book) throws Exception;

	public void update(Book book) throws Exception;

	public void delete(String isbn) throws Exception;

	public Book select(String isbn) throws Exception;

	public List<Book> search(SearchCondition condition) throws Exception;
}
