package hwalgo25_서울_7반_최다윗;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Hwalgo25_서울_7반_최다윗 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine().trim(), " ");
		int c = Integer.parseInt(st.nextToken());
		int r = Integer.parseInt(st.nextToken());
		int n = Integer.parseInt(br.readLine().trim());
		int[][] arr = new int[n + 1][3];
		int dir;
		for (int i = 0; i < n + 1; i++) {
			st = new StringTokenizer(br.readLine().trim(), " ");
			arr[i][0] = Integer.parseInt(st.nextToken());
			arr[i][1] = Integer.parseInt(st.nextToken());
			dir = arr[i][0];
			if (dir == 1 || dir == 2) {
				arr[i][2] = c - arr[i][1];
			} else {
				arr[i][2] = r - arr[i][1];
			}
		}
		// 기준
		dir = arr[n][0];
		int point = arr[n][1];
		int rpoint = arr[n][2];

		// result
		int result = 0;
		for (int i = 0; i < n; i++) {
			int tmp = arr[i][0];
			int tmpPoint = arr[i][1];
			int tmpRPoint = arr[i][2];
			// 같은곳
			if (dir == tmp)
				result += Math.abs(tmpPoint - point);
			// 페어
			else if ((dir < 3 && tmp < 3)) {
				result += Math.min(point + tmpPoint, rpoint + tmpRPoint);
				result += r;
			} else if ((dir > 2 && tmp > 2)) {
				result += Math.min(point + tmpPoint, rpoint + tmpRPoint);
				result += c;
			} else {
				// 다를때
				result += dir == 3 || dir == 1 ? tmpPoint : tmpRPoint;
				result += tmp == 3 || tmp == 1 ? point : rpoint;
			}

		}
		System.out.println(result);
	}
}
