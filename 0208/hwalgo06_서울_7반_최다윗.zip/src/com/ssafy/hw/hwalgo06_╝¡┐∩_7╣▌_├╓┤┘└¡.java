package com.ssafy.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Stack;
import java.util.StringTokenizer;

public class hwalgo06_����_7��_�ִ��� {
	
	private static int result;

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.parseInt(br.readLine().trim());
		int shap = 0;
		StringTokenizer st;
		while (shap++<t) {
			st = new StringTokenizer(br.readLine().trim(), " ");
			int n = Integer.parseInt(st.nextToken());
			int m = Integer.parseInt(st.nextToken());
			
			st = new StringTokenizer(br.readLine().trim(), " ");
			int[] arr = new int[n];
			for (int i = 0; i < n; i++) {
				arr[i] = Integer.parseInt(st.nextToken());
			}
			
			result=-1;
			combi(0,new int[2],0,arr,m);
			
			StringBuilder sb = new StringBuilder();
			sb.append("#").append(shap).append(" ").append(result);
			System.out.println(sb.toString());
		}
	}

	private static void combi(int toSelect, int[] selected, int start, int[] arr, int m) {
		if(toSelect ==2) {
			int sum = selected[0] + selected[1];
			if(sum<=m)
				result = Math.max(result, sum);
			return;
		}
		
		for (int i = start; i < arr.length; i++) {
			selected[toSelect] = arr[i];
			combi(toSelect+1, selected, i+1, arr, m);
		}
		
	}
}
