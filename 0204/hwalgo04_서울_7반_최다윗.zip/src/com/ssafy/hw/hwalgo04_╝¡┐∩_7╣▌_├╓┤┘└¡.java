package com.ssafy.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Stack;
import java.util.StringTokenizer;

public class hwalgo04_����_7��_�ִ��� {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine().trim());
		PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();
		int[] result = new int[n];
		
		HashMap<Integer,Integer> index = new HashMap<Integer,Integer>();
		Stack<Integer> stack = new Stack<Integer>();
		StringTokenizer st = new StringTokenizer(br.readLine().trim()," ");
		for (int i = 0; i < n; i++) {
			stack.push(Integer.parseInt(st.nextToken()));
			index.put(stack.peek(), i);
		}
	
		//stack ���� 
		while(!stack.isEmpty()) {
			int stacktmp = stack.pop();
			//queue�� ����� ���� �� end:pass������
			while(!priorityQueue.isEmpty()) {
				int queuetmp = priorityQueue.poll();
				if(stacktmp > queuetmp) {
					result[index.get(queuetmp)]=index.get(stacktmp)+1;	
				}else {
					priorityQueue.add(queuetmp);
					break;
				}
			}
			//ó�� ���Ҵ� �׻� 0�� ���´�.
			if(stack.isEmpty()) {
				result[index.get(stacktmp)]=0;
				break;
			}
			
			//stacktmp�� ������ if ������ �ε��� ����, else ť�� �ֱ�;
			if(stack.peek()>stacktmp)
				result[index.get(stacktmp)]=index.get(stack.peek())+1;
			else
				priorityQueue.add(stacktmp);
		}//while end
		
		//���� queue 0���� ó��.
		while(!priorityQueue.isEmpty()) {
			result[index.get(priorityQueue.poll())]=0;
		}
		StringBuilder sb = new StringBuilder();
		for (Integer integer : result) {
			sb.append(integer).append(" ");
		}
		System.out.println(sb.toString());
		
	}
}
