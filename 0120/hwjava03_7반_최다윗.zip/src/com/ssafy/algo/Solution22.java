package com.ssafy.algo;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Solution22 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		System.setIn(new FileInputStream("src/input.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int TestCase = Integer.parseInt(br.readLine().trim());
		int number = 1;

		while (TestCase >= number) {
			// 배열크기와 소금쟁이 수 받기
			StringTokenizer st = new StringTokenizer(br.readLine(), " ");
			int n = Integer.parseInt(st.nextToken());
			int numberOfWS = Integer.parseInt(st.nextToken());

			// 연못과 소금쟁이 초기 위치 설정
			int[][] pond = new int[n][n];
			String[] order = new String[numberOfWS];
			for (int i = 0; i < numberOfWS; i++) {
				order[i] = br.readLine();
				st = new StringTokenizer(order[i], " ");
				int x = Integer.parseInt(st.nextToken());
				int y = Integer.parseInt(st.nextToken());
				int direction = Integer.parseInt(st.nextToken());

				// 소금쟁이가 없으면 살고 있으면 죽임 즉, 추가 않함.
				if (pond[x][y] == 0) {
					pond[x][y] = direction;
				}
			}
			// 살아남은 소금쟁이 수
			int cnt = 0;

			

			// 순서대로 소금쟁이 움직임(단, 소금쟁이가 있다면 초기값 0으로 다시 셋팅
			for (int i = 0; i < order.length; i++) {
				st = new StringTokenizer(order[i], " ");
				int x = Integer.parseInt(st.nextToken());
				int y = Integer.parseInt(st.nextToken());
				int direction = pond[x][y];
				pond[x][y] = 0;
				
				//방향으로 전진시 아웃 or 충돌 하지 않으면 cnt++
				//상하좌우의 정의가 없어서 아래와 같이 함.
				//상(x--)하(x++) => 행의 변화(x값의 변화), 좌(y--)우(y++) =>열의 변화 (y값의 변화)
				switch(direction) {
				case 1:
					if(x-6<0||pond[x-3][y]!=0||pond[x-5][y]!=0||pond[x-6][y]!=0)
						break;
					else {
						pond[x-6][y] = direction;
						cnt++;
					}
				case 2:
					if(x+6>n-1||pond[x+3][y]!=0||pond[x+5][y]!=0||pond[x+6][y]!=0)
						break;
					else {
						pond[x+6][y] = direction;
						cnt++;
					}
				case 3:
					if(y-6<0||pond[x][y-3]!=0||pond[x][y-5]!=0||pond[x][y-6]!=0)
						break;
					else {
						pond[x][y-6] = direction;
						cnt++;
					}					
				case 4:
					if(y+6>n-1||pond[x][y+3]!=0||pond[x][y+5]!=0||pond[x][y+6]!=0)
						break;
					else {
						pond[x][y+6] = direction;
						cnt++;
					}
				}
			}
			System.out.println("#"+(number++)+" "+cnt);
		}// while close
		br.close();
	}
}
