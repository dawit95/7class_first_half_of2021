package com.ssafy;

public class TV {
	private String serialNumber;
	private String name;
	private int price;
	private int quantity;
	private int inch;
	private String displayType;

	public TV() {
		this("000-0000", "삼성 TV", 800000, 100, 50, "OLED");
	}

	public TV(int inch, String displayType) {
		this("000-0000", "삼성 TV", 800000, 100, inch, displayType);
	}

	public TV(String serialNumber, String name, int price, int quantity, int inch, String displayType) {
		this.serialNumber = serialNumber;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.inch = inch;
		this.displayType = displayType;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	public String getDisplayType() {
		return displayType;
	}

	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("이 제품은 ");
		sb.append(this.name);
		sb.append("이며 인치 : ");
		sb.append(this.inch);
		sb.append(", 디스플레이 타입 : ");
		sb.append(this.displayType);
		sb.append("입니다.\n가격은 ");
		sb.append(this.price);		
		sb.append("원 이고 남은 수량은 ");
		sb.append(this.quantity);
		sb.append("입니다.\n추가로 제품번호는");
		sb.append(this.serialNumber);
		
		return sb.toString();
	}
}
