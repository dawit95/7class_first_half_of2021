package com.ssafy;

public class ProductTest {

	public static void main(String[] args) {

		TV tv1 = new TV(70,"LED");
		System.out.println(tv1.toString());
		System.out.println();
		
		TV tv2 = new TV(70,"LED");
		System.out.println(tv2.toString());
		System.out.println();
		
		TV tv3 = new TV();
		tv3.setDisplayType("LCD");
		tv3.setInch(60);
		System.out.println(tv3.getInch()+"인치 "+tv3.getDisplayType()+"타입의 TV.");
		System.out.println();
		
		Refrigerator refrigerator1 = new Refrigerator();
		System.out.println(refrigerator1.toString());
		System.out.println();		
		
		Refrigerator refrigerator2 = new Refrigerator(256);
		System.out.println(refrigerator2.toString());
		System.out.println();
		
		Refrigerator refrigerator3 = new Refrigerator();
		refrigerator3.setVolume(500);
		System.out.println(refrigerator2.getVolume()+"L의 냉장고");
		System.out.println();
		
		

	}

}
