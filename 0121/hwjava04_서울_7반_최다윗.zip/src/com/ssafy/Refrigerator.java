package com.ssafy;

public class Refrigerator {
	private String serialNumber;
	private String name;
	private int price;
	private int quantity;
	private int volume;
	
	public Refrigerator() {
		this("000-0000", "삼성 냉장고", 10000000, 100, 350);
	}
	
	public Refrigerator(int volume) {
		this("000-0000", "삼성 냉장고", 10000000, 100, volume);
	}

	public Refrigerator(String serialNumber, String name, int price, int quantity, int volume) {
		this.serialNumber = serialNumber;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.volume = volume;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("이 제품은 ");
		sb.append(this.name);
		sb.append("이며 용량(L) : ");
		sb.append(this.volume);
		sb.append("L입니다.\n가격은 ");
		sb.append(this.price);		
		sb.append("원 이고 남은 수량은 ");
		sb.append(this.quantity);
		sb.append("입니다.\n추가로 제품번호는");
		sb.append(this.serialNumber);
		
		return sb.toString();
	}

}
