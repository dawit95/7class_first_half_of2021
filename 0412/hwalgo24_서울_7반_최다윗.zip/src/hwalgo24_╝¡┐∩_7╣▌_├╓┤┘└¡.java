import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.PriorityQueue;

public class hwalgo24_서울_7반_최다윗 {

	static class Point implements Comparable<Point>{
		int r;
		int c;
		int value;
		public Point(int r, int c, int value) {
			super();
			this.r = r;
			this.c = c;
			this.value = value;
		}
		
		@Override
		public int compareTo(Point o) {
			return Integer.compare(this.value, o.value);
		}
		
	}
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int testcase = Integer.parseInt(br.readLine().trim());
		for (int t = 0; t < testcase; t++) {
			int n = Integer.parseInt(br.readLine().trim());
			int[][] map = new int[n][n];
			
			for (int i = 0; i < n; i++) {
				String[] str = br.readLine().trim().split("");
				for (int j = 0; j < n; j++) {
					map[i][j]= Integer.parseInt(str[j]);
				}
			}
			
			PriorityQueue<Point> queue = new PriorityQueue<Point>();
			queue.offer(new Point(0,0,map[0][0]));
			int[][] value = new int[n][n];
			for (int i = 0; i < n; i++) {
				Arrays.fill(value[i], Integer.MAX_VALUE);
			}
			boolean[][] visited = new boolean[n][n];
			visited[0][0] = true;
			
			int[] dr = {0,-1,0,1};
			int[] dc = {-1,0,1,0};
			
			while(!queue.isEmpty()) {
				Point now = queue.poll();
				
				if(now.r==n-1&&now.c==n-1) {
					value[now.r][now.c] = now.value>value[now.r][now.c]?value[now.r][now.c]:now.value;
				}
				
				for (int i = 0; i < 4; i++) {
					int tmpr = now.r+dr[i];
					int tmpc = now.c+dc[i];
					if(tmpr<0||n-1<tmpr||tmpc<0||n-1<tmpc) continue;
					int tmp =now.value+map[tmpr][tmpc];
					if(!visited[tmpr][tmpc] && value[tmpr][tmpc]>tmp) {
						value[tmpr][tmpc] = tmp;
						visited[tmpr][tmpc] = true;
						queue.offer(new Point(tmpr,tmpc,tmp));
					}
				}
				
			}
			System.out.println("#"+(t+1)+" "+value[n-1][n-1]);
		}
	}
}
