package com.hw.product;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registration.do")
public class registration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String productName = request.getParameter("productName");
		String productPrice = request.getParameter("productPrice");
		String productDescription = request.getParameter("productDescription");

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("	<body>");
		out.println("	<div align=\"center\">");
		out.println("상품 : " + productName + "입니다!!!<br>");
		out.println("가격 : " + productPrice + "$<br>");
		out.println("설명 : " + productDescription + "!!!<br>");
		out.println("	</div>");
		out.println("	</body>");
		out.println("</html>");
	}

}
