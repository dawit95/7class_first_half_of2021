use ssafydb;

drop table hw_product;

create table hw_product (
	idx          int          not null auto_increment,
	productname       varchar(20)  not null,
	productprice     varchar(20),
	productcontext      varchar(100),
	joindate     timestamp    not null default current_timestamp,
	primary key (idx)
);

insert into hw_product (productname, productprice, productcontext, joindate)
values ('samsungTv', '1,000,000', 'smartTv very nice!', now());