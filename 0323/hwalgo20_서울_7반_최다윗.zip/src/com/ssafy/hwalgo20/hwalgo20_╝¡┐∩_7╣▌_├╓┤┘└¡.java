package com.ssafy.hwalgo20;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class hwalgo20_서울_7반_최다윗 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine().trim());
		int[][] cost = new int[n][3];
				
		for (int i = 0; i < n; i++) {
			String[] str = br.readLine().trim().split(" ");
			cost[i][0] = Integer.parseInt(str[0]);
			cost[i][1] = Integer.parseInt(str[1]);
			cost[i][2] = Integer.parseInt(str[2]);		
		}
		
		
		for (int i = 0; i < n; i++) {
			cost[i][0] += Math.min(cost[i-1][1], cost[i-1][2]);
			cost[i][1] += Math.min(cost[i-1][0], cost[i-1][2]);
			cost[i][2] += Math.min(cost[i-1][0], cost[i-1][1]);
		}
		
		int answer = Math.min(cost[n-1][0], Math.min(cost[n-1][1], cost[n-1][2]));
		System.out.println(answer);

	}

}
