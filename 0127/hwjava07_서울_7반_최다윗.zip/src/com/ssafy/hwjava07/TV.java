package com.ssafy.hwjava07;

public class TV extends Product {

	private int inch;
	private String displayType;

	public TV() {
		this(0,"TV이름",0,0);
		this.inch = 0;
		this.displayType = "TV타입";
	}

	public TV(int serialNumber, String name, int price, int quantity) {
		super(serialNumber, name, price, quantity);
		this.inch = 0;
		this.displayType = "TV타입";
	}
	
	public TV(int serialNumber, String name, int price, int quantity, int inch, String displayType) {
		super(serialNumber, name, price, quantity);
		this.inch = inch;
		this.displayType = displayType;
	}

	public int getInch() {
		return inch;
	}

	public String getDisplayType() {
		return displayType;
	}

	@Override
	public String toString() {
		return "TV [getSerialNumber()=" + getSerialNumber() + ", getName()=" + getName() + ", getPrice()=" + getPrice()
				+ "원, getQuantity()=" + getQuantity() + "개, inch=" + inch + ", displayType=" + displayType + "]";
	}
	
	
}
