package com.ssafy.hwjava07;

import java.util.ArrayList;

public class ProductTest {

	private static ProductMgrImpl productMgr = ProductMgrImpl.getInstance();

	public static void main(String[] args) {

		list();
		add();
		list();
		System.out.println();
		
		search(4567);
		System.out.println();
		
		search("삼");
		System.out.println();
		
		searchTv();
		System.out.println();
		
		searchRefrigerator();
		System.out.println();
		
		searchTv(50);
		System.out.println();
		
		searchRefrigerator(500);
		System.out.println();
		
		search(7890);
		System.out.println("*********************7890상품 가격 변경(350000)*********************");
		productMgr.updatePrice(7890, 350000);
		search(7890);
		System.out.println();
		
		System.out.println("*********************상품 제거:789*********************");
		productMgr.delete(789);
		search(789);
		System.out.println();
		
		System.out.println("*********************등록된 상품 총 금액*********************");
		int totalPrice = productMgr.totalPrice();
		System.out.println("등록된 제품의 총 금액 : " + totalPrice + "원");
	}

	private static void searchRefrigerator(int volume) {
		System.out.println("*********************냉장고상품 중 " + volume + "L이상 상품 조회*********************");
		ArrayList<Refrigerator> refrigerator = productMgr.RefrigeratorList(volume);
		if (!refrigerator.isEmpty())
			for (Refrigerator product : refrigerator) {
				System.out.println(product);
			}
		else
			System.err.println("제품이 없습니다.");

	}

	private static void searchRefrigerator() {
		System.out.println("*********************냉장고 상품만 조회*********************");
		ArrayList<Refrigerator> refrigerator = productMgr.RefrigeratorList();
		if (!refrigerator.isEmpty())
			for (Refrigerator product : refrigerator) {
				System.out.println(product);
			}
		else
			System.err.println("제품이 없습니다.");

	}

	private static void searchTv(int inch) {
		System.out.println("*********************TV상품 중" + inch + "inch이상 상품 조회*********************");
		ArrayList<TV> tvs = productMgr.TVList(inch);
		if (!tvs.isEmpty())
			for (TV product : tvs) {
				System.out.println(product);
			}
		else
			System.err.println("제품이 없습니다.");

	}

	private static void searchTv() {
		System.out.println("*********************TV상품만 조회*********************");
		ArrayList<TV> tvs = productMgr.TVList();
		if (!tvs.isEmpty())
			for (TV product : tvs) {
				System.out.println(product);
			}
		else
			System.err.println("제품이 없습니다.");
	}

	private static void add() {
		System.out.println("*********************상품 저장!!!*********************");
		productMgr.add(new Refrigerator(123, "LG 냉장고", 500000, 20, 500));
		productMgr.add(new TV(456, "LG TV", 800000, 20, 65, "QLED"));
		productMgr.add(new TV(457, "Google TV", 400000, 20, 42, "QLED"));
		productMgr.add(new Refrigerator(1234, "삼성 냉장고", 400000, 20, 300));
		productMgr.add(new TV(4567, "삼성 TV", 900000, 20, 70, "QLED"));
		productMgr.add(new Refrigerator(7890, "대우 냉장고", 450000, 20, 400));

	}

	private static void list() {
		System.out.println("*********************상품목록*********************");
		ArrayList<Product> products = productMgr.list();
		if (!products.isEmpty())
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.err.println("제품이 없습니다.");
	}

	private static void search(String string) {
		System.out.println("*********************상품이름으로 조회:" + string + "*********************");
		ArrayList<Product> products = productMgr.list(string);
		if (!products.isEmpty())
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.err.println("조회하신 이름의 제품이 없습니다.");

	}

	private static void search(int serialNumber) {
		System.out.println("*********************상품 조회:" + serialNumber + "*********************");
		Product p = productMgr.list(serialNumber);
		if (p != null)
			System.out.println(p);
		else
			System.err.println("제품이 없습니다.");
	}

}
