package com.ssafy.news;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.*;

import org.xml.sax.SAXException;

public class NewsDAOSAXImpl implements INewsDAO{
	
	private static List<News> list;

	@Override
	public List<News> getNewsList(String url) {
		list = new ArrayList<News>();
		connectNews(url);
		return list;
	}

	@Override
	public News search(int index) {
		return list.get(index);
	}
	
	private void connectNews(String url) {

//		File file = new File(url);
//		System.out.println(file.toString());
		SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		
		SAXParser saxParser;
		try {
			saxParser = saxParserFactory.newSAXParser();
			SAXHandler handler = new SAXHandler(list);
			saxParser.parse(url, handler);
			
			this.list = handler.getNewsList();
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
	}

}
