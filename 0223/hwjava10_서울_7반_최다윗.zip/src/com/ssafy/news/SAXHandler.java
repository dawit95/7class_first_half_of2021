package com.ssafy.news;

import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXHandler extends DefaultHandler {

	private StringBuilder b = new StringBuilder();
	private boolean flag = false;
	private List<News> list;
	private News n ;
	
	boolean title = false;
	boolean link = false;
	boolean desc = false;
	

	public SAXHandler(List<News> list) {
		this.list = list;
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
//		if (qName.equals("author")) {
//			bAuthor = true;
//		} else if (qName.equals("about")) {
//			bAbout = true;
//		} else if (qName.equals("date")) {
//			bDate = true;
//		} else if (qName.equals("year")) {
//			bYear = true;
//		} else if (qName.equals("month")) {
//			bMonth = true;
//		} else if (qName.equals("day")) {
//			bDay = true;
//		}

		switch (qName) {
		case "title":
			n=new News();
			title = true;
			break;
		case "description":
			desc = true;
			break;
		case "link":
			link = true;
			break;
		}
		b = new StringBuilder();
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
//		if (bAuthor) {
//			vr.setAuthor(data.toString());
//			bAuthor = false;
//		} else if (bAbout) {
//			vr.setAbout(data.toString());
//			bAbout = false;
//		} else if (bYear) {
//			dateStr.append(data.toString());
//			bYear = false;
//		} else if (bMonth) {
//			dateStr.append(data.toString());
//			bMonth = false;
//		} else if (bDay) {
//			dateStr.append(data.toString());
//			bDay = false;
//		} else if (bDate) {
//			vr.setDate(dateStr.toString());
//			bDate = false;
//		}
		if(title) {
			n.setTitle(b.toString());
			title = false;
		} else if(link) {
			n.setLink(b.toString());
			link = false;
		}else if(desc) {
			n.setDesc(b.toString());
			desc = false;
			list.add(n);
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		b.append(new String(ch, start, length));
	}

	public List<News> getNewsList() {
		return list;
	}

}
