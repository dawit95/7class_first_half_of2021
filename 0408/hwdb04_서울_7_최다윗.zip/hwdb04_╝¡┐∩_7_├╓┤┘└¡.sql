-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema ssafyhw
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `ssafyhw` ;

-- -----------------------------------------------------
-- Schema ssafyhw
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ssafyhw` DEFAULT CHARACTER SET utf8 ;
USE `ssafyhw` ;

-- -----------------------------------------------------
-- Table `ssafyhw`.`user`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ssafyhw`.`user` ;

CREATE TABLE IF NOT EXISTS `ssafyhw`.`user` (
  `userno` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(30) NOT NULL,
  `useraddress` VARCHAR(200) NOT NULL,
  `userphone1` VARCHAR(30) NOT NULL,
  `userphone2` VARCHAR(30) NULL,
  PRIMARY KEY (`userno`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ssafyhw`.`order`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ssafyhw`.`order` ;

CREATE TABLE IF NOT EXISTS `ssafyhw`.`order` (
  `orderno` INT NOT NULL AUTO_INCREMENT,
  `orderprice` VARCHAR(100) NOT NULL,
  `orderdate` DATE NULL,
  `userno` INT NULL,
  `payment` VARCHAR(45) NULL,
  `delivery` VARCHAR(45) NULL,
  PRIMARY KEY (`orderno`),
  INDEX `order_userno_fk_idx` (`userno` ASC) VISIBLE,
  CONSTRAINT `order_userno_fk`
    FOREIGN KEY (`userno`)
    REFERENCES `ssafyhw`.`user` (`userno`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ssafyhw`.`product`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ssafyhw`.`product` ;

CREATE TABLE IF NOT EXISTS `ssafyhw`.`product` (
  `productcode` INT NOT NULL AUTO_INCREMENT,
  `productname` VARCHAR(45) NULL,
  `ea` INT NULL,
  `price` INT NULL,
  PRIMARY KEY (`productcode`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ssafyhw`.`order_detail`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ssafyhw`.`order_detail` ;

CREATE TABLE IF NOT EXISTS `ssafyhw`.`order_detail` (
  `orderno` INT NOT NULL,
  `productcode` INT NOT NULL,
  `cnt` INT NULL,
  INDEX `order_detail_productcode_fk_idx` (`productcode` ASC) VISIBLE,
  INDEX `order_detail_orderno_fk_idx` (`orderno` ASC) VISIBLE,
  PRIMARY KEY (`orderno`, `productcode`),
  CONSTRAINT `order_detail_productcode_fk`
    FOREIGN KEY (`productcode`)
    REFERENCES `ssafyhw`.`product` (`productcode`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `order_detail_orderno_fk`
    FOREIGN KEY (`orderno`)
    REFERENCES `ssafyhw`.`order` (`orderno`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
