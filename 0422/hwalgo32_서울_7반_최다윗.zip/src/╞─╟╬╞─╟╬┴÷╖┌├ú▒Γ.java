import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class 파핑파핑지뢰찾기 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int test = Integer.parseInt(br.readLine().trim());
		for (int t = 1; t <= test; t++) {
			int n = Integer.parseInt(br.readLine().trim());
			char[][] map = new char[n][n];
			for (int i = 0; i < n; i++) {
				map[i] = br.readLine().trim().toCharArray();
			}

			makeMap(map);

			int ans = 0;
			boolean[][] visited = new boolean[n][n];
			// 남은거 중에 방문하지 않고 *이 아닌 것
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (!visited[i][j] && map[i][j] == '0') {
						bfs(i, j, map, visited);
						ans++;
					}
				}
			}

			int cnt = 0;
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (!visited[i][j] && map[i][j] != '*')
						cnt++;
				}
			}

			System.out.println("#" + t + " " + (ans + cnt));
		}
	}

	// 상, 우, 하, 좌, 좌상, 우상, 우하,좌하
	static int[] dr = { -1, 0, 1, 0, -1, -1, 1, 1 };
	static int[] dc = { 0, 1, 0, -1, -1, 1, 1, -1 };

	/*
	 * 클릭한 좌표 주변에 0이면 탐색 아니면 끝 단, 숫자의 경우 true처리 끝, 0인경우 queue에 삽입
	 */
	private static void bfs(int r, int c, char[][] map, boolean[][] visited) {
		Queue<int[]> queue = new LinkedList<int[]>();
		visited[r][c] = true;
		queue.offer(new int[] { r, c });
		while (!queue.isEmpty()) {
			int[] nowArr = queue.poll();
			int row = nowArr[0];
			int col = nowArr[1];

			for (int i = 0; i < 8; i++) {
				int tmpR = row + dr[i];
				int tmpC = col + dc[i];
				if (isRalidity(tmpR, tmpC, visited.length))
					continue;
				if (!visited[tmpR][tmpC] && map[tmpR][tmpC] == '0') {
					visited[tmpR][tmpC] = true;
					queue.offer(new int[] { tmpR, tmpC });
				}
				if (!visited[tmpR][tmpC]) {
					visited[tmpR][tmpC] = true;
				}
			}
		}
	}

	private static void makeMap(char[][] map) {
		int n = map.length;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (map[i][j] == '*')
					continue;
				int cnt = 0;
				for (int dir = 0; dir < 8; dir++) {
					int r = i + dr[dir];
					int c = j + dc[dir];
					if (isRalidity(r, c, n))
						continue;
					if (map[r][c] == '*')
						cnt++;
				}
				map[i][j] = (char) (cnt + '0');
			}
		}
	}

	private static boolean isRalidity(int tmpR, int tmpC, int n) {
		return (tmpR < 0 || tmpR > n - 1 || tmpC < 0 || tmpC > n - 1);
	}

}
