package com.ssafy.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

public class hwalgo10_����_7��_�ִ��� {

	public static void main(String[] args) throws IOException, NumberFormatException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine().trim());
		List<int[]> list = new LinkedList<int[]>();
		for (int i = 0; i < n; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine().trim(), " ");
			int[] arr = new int[2];
			arr[0] = Integer.parseInt(st.nextToken());
			arr[1] = Integer.parseInt(st.nextToken());
			list.add(arr);
		}

		Collections.sort(list, (int[] o1, int[] o2) -> {
			int diff = o1[0] - o2[0];
			return diff != 0 ? diff : o1[1] - o2[1];
		});

		int result = 1;
		int idx = list.size() - 1;
		int min = list.get(idx)[0];
		while (!list.isEmpty()) {
			int[] pivot = list.get(idx);
			if (pivot[0] <= min && pivot[1] >= min) {
				list.remove(idx--);
			} else {
				min = list.get(idx)[0];
				result++;
			}
		}
		System.out.println(result);
	}
}
