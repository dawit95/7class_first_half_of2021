package com.ssafy.hwalgo16;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class hwalgo16_서울_7반_최다윗 {

	static int result, n;
	static int[][] arr;

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine().trim());
		arr = new int[n][n];
		for (int i = 0; i < n; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine().trim(), " ");
			for (int j = 0; j < n; j++) {
				arr[i][j] = Integer.parseInt(st.nextToken());
			}
		}
		result = Integer.MAX_VALUE;

		com(0, new boolean[n], 0);
		System.out.println(result);
	}

	private static void com(int cnt, boolean[] selected, int idx) {
		if (cnt == (n / 2)) {
			sol(selected);
			return;
		}

		for (int i = idx; i < n; i++) {
			selected[i] = true;
			com(cnt + 1, selected, i + 1);
			selected[i] = false;
		}

	}

	private static void sol(boolean[] visited) {
		int food1 = 0;
		int food2 = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				boolean rIdx = visited[i];
				boolean cIdx = visited[j];
				if (rIdx && cIdx) {
					food1 += arr[i][j];
				} else if (!rIdx && !cIdx) {
					food2 += arr[i][j];
				}
			}
		}
		result = Math.min(result, Math.abs(food1 - food2));
	}
}
