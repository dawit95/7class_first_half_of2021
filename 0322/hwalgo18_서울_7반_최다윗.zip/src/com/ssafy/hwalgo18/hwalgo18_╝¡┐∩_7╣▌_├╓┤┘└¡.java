package com.ssafy.hwalgo18;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class hwalgo18_서울_7반_최다윗 {

	static int V, cost, min = Integer.MAX_VALUE;
	static boolean[] visited;
	static int[][] map ;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		V = Integer.parseInt(br.readLine().trim());
		map = new int[V][V];
		visited = new boolean[V];
		
		for (int i = 0; i < V; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine().trim(), " ");
			for (int j = 0; j < V; j++) {
				int tmpCol = Integer.parseInt(st.nextToken());
				map[i][j]=tmpCol;
			}
		}

		visited[0] = true;
		dfs(0,0,0);
		System.out.println(min);

	}

	/*
	 * 현재노드, 선택된 노드갯수 ,누적값.
	 */
	private static void dfs(int now, int seleted, int cost) {
		if(seleted == V-1) {
			if(map[now][0] == 0)
				return;
			cost += map[now][0];
			min = Math.min(min, cost);
		}
		//가지치기
		if(cost>min) {
			return;
		}
		
		for (int i = 0; i < V; i++) {
			if(visited[i]) continue;
			if(map[now][i] == 0) continue;
			
			visited[i] = true;
			dfs(i,seleted+1,cost+map[now][i]);
			visited[i] = false;
		}
		
	}
}
