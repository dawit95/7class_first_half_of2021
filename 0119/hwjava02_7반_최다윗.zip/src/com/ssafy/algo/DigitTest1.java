package com.ssafy.algo;

import java.util.Scanner;

public class DigitTest1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[] resultArray = new int[10];
		
		//0이 들어올때까지 받기!
		while (true) {
			int targetNum = input.nextInt();
			if (targetNum == 0)
				break;
			resultArray[targetNum / 10]++;
		}
		input.close();
		
		//정답 출력
		for (int i = 0; i < 10; i++) {
			if (resultArray[i] != 0)
				System.out.println(i + " : " + resultArray[i] + "개");
		}
	}
}
