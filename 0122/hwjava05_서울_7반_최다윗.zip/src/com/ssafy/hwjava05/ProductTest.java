package com.ssafy.hwjava05;

public class ProductTest {

	public static void main(String[] args) {
		ProductMgr productMgr = new ProductMgr();

		System.out.println("*********************상품목록*********************");
		Product[] products = productMgr.list();
		if(products.length != 0)
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.out.println("제품이 없습니다.");
		
		System.out.println("*********************상품 저장!!!*********************");
		productMgr.add(new Product(123,"LG 냉장고",500000,100));
		productMgr.add(new Product(456,"LG TV",800000,100));
		productMgr.add(new Product(789,"LG 세탁기",400000,100));
		productMgr.add(new Product(1234,"삼성 냉장고",300000,100));
		productMgr.add(new Product(4567,"삼성 TV",900000,100));
		productMgr.add(new Product(7890,"삼성 세탁기",450000,100));
		
		System.out.println("*********************상품목록*********************");
		products = productMgr.list();
		if(products.length != 0)
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.out.println("제품이 없습니다.");
		
		System.out.println("*********************상품번호로 조회:789*********************");
		Product p = productMgr.list(456);
		if(p != null)
			System.out.println(p);
		else
			System.out.println("제품이 없습니다.");
		
		System.out.println("*********************상품 제거:789*********************");
		productMgr.delete(789);
		
		System.out.println("*********************상품목록*********************");
		products = productMgr.list();
		if(products.length != 0)
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.out.println("제품이 없습니다.");
		
		System.out.println("*********************50만원 이하의 상품*********************");
		products = productMgr.priceList(500000);
		if(products.length != 0)
			for (Product product : products) {
				System.out.println(product);
			}
		else
			System.out.println("50만원 이하의 제품이 없습니다.");
	}

}
