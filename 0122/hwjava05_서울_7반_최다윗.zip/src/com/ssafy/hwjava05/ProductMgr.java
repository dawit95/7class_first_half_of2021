package com.ssafy.hwjava05;

public class ProductMgr {

	private static int MAX_SIZE = 100;
	private Product[] products = new Product[MAX_SIZE];
	private int size = 0;

	public void add(Product p) {
		if (size < 100) {
			products[size] = p;
			size++;
		}
	}

	public Product[] list() {
		Product[] newProducts = new Product[size];
		for (int i = 0; i < size; i++) {
			newProducts[i] = products[i];
		}
		return newProducts;
	}

	public Product list(int num) {
		for (int i = 0; i < size; i++) {
			if (products[i].getSerialNumber() == num) {
				return products[i];
			}
		}
		return null;
	}

	public void delete(int num) {
		for (int i = 0; i < size; i++) {
			if (products[i].getSerialNumber() == num) {
				products[i] = products[size - 1];
				size--;
			}
		}
	}

	public Product[] priceList(int price) {
		ProductMgr pm = new ProductMgr();
		for (int i = 0; i < size; i++) {
			if (products[i].getPrice() <= price) {
				pm.add(products[i]);
			}
		}
		return pm.list();

	}

}
