package com.ssafy.hw.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.hw.aop.LoggingAspect;
import com.ssafy.hw.model.dto.Product;
import com.ssafy.hw.model.mapper.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
	
	
	private Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);

	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<Product> selectAll() throws Exception {
		logger.debug("listAll~");
		return sqlSession.getMapper(ProductRepo.class).selectAll();
	}

	@Override
	public Product select(String id) throws Exception {
		return sqlSession.getMapper(ProductRepo.class).select(id);
	}

	@Override
	public int insert(Product product) throws Exception {
		if(product.getId() == null)
			throw new Exception();
		return sqlSession.getMapper(ProductRepo.class).insert(product);
	}

	@Override
	public int update(Product product) throws Exception {
		return sqlSession.getMapper(ProductRepo.class).update(product);
	}

	@Override
	public int delete(String id) throws Exception {
		return sqlSession.getMapper(ProductRepo.class).delete(id);
	}

}
