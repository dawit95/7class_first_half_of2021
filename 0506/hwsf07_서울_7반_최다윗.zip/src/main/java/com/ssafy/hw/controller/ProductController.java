package com.ssafy.hw.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.hw.model.dto.Product;
import com.ssafy.hw.model.service.ProductService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/product")
@CrossOrigin("*")
@Api(value = "Product")
public class ProductController {

	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

	@Autowired
	private ProductService productService;

//	// regist페이지로 이동
//	@GetMapping("/regist")
//	public String write() {
//		return "product/regist";
//	}
//
//	@PostMapping("/regist")
//	public String regist(Product product, Model model) {
//		logger.debug("regist!!!");
//		try {
//			productService.insert(product);
//			logger.debug("등록 성공");
//			return "redirect:list";
//		} catch (Exception e) {
//			e.printStackTrace();
//			model.addAttribute("msg", "상품 등록중 문제가 발생했습니다.");
//			return "error/error";
//		}
//	}
//
//	@GetMapping("/list")
//	public String list(Model model) {
//		logger.debug("list!!!");
//		try {
//			List<Product> list = productService.selectAll();
//			model.addAttribute("productList", list);
//			logger.debug("list 불러오기 성공!!!");
//		} catch (Exception e) {
//			e.printStackTrace();
//			model.addAttribute("msg", "상품 목록을 가져오는 중에 문제가 발생했습니다.");
//			return "error/error";
//		}
//		return "product/list";
//	}
	
	/////////////////////////////////////////////////////////////
	
	@ApiOperation(value = "물품 리스트",notes = "모든 물품 리스트를 반환", response = List.class)
	@GetMapping(value = "/list")
	public ResponseEntity<List<Product>> userList() throws Exception {
		logger.debug("product/list 들어왔음!!!!!!!!!");
		List<Product> list = productService.selectAll();
		if(list != null && !list.isEmpty()) {
			return new ResponseEntity<List<Product>>(list, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
	
	@ApiOperation(value = "물품 등록",notes = " 하나의 물품 등록")
	@PostMapping(value = "/list")
	public ResponseEntity<List<Product>> userRegister(@RequestBody @ApiParam(value = "등록할 상품 정보", required = true) Product product) throws Exception {
		int cnt = productService.insert(product);
		if(cnt != 0) {
			List<Product> list = productService.selectAll();
			return new ResponseEntity<List<Product>>(list, HttpStatus.OK);
//			return new ResponseEntity<Integer>(cnt, HttpStatus.CREATED);
		} else
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@ApiOperation(value = "물품 정보",notes = " 하나의 물품 정보를 id로 조회")
	@GetMapping(value = "/list/{id}")
	public ResponseEntity<Product> userInfo(@PathVariable("id") @ApiParam(value = "조회할 상품 id", required = true) String id) throws Exception {
		logger.debug("파라미터 : {}", id);
		Product product = productService.select(id);
		if(product != null)
			return new ResponseEntity<Product>(product, HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@ApiOperation(value = "물품 정보 수정",notes = " 물품 정보를 수정후 다시 리스트 반환")
	@PutMapping(value = "/list")
	public ResponseEntity<List<Product>> userModify(@RequestBody @ApiParam(value = "수정 정보", required = true) Product product) throws Exception {
		productService.update(product);
		List<Product> list = productService.selectAll();
		return new ResponseEntity<List<Product>>(list, HttpStatus.OK);
	}
	
	@ApiOperation(value = "물품 삭제",notes = "id가 같은 물품 삭제 후 다시 리스트 반환")
	@DeleteMapping(value = "/list/{id}")
	public ResponseEntity<List<Product>> userDelete(@PathVariable("id") @ApiParam(value = "삭제 상품 id", required = true) String id) throws Exception {
		productService.delete(id);
		List<Product> list = productService.selectAll();
		return new ResponseEntity<List<Product>>(list, HttpStatus.OK);
	}
}
