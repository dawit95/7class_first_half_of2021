package com.ssafy.hw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hwsf07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
