package com.ssafy.hwjava09;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class hwjava09_서울_7반_최다윗 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine().trim());
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

		ArrayList<HashMap<Integer, Integer>> arr = new ArrayList<HashMap<Integer, Integer>>();
		for (int i = 0; i < n; i++) {
			String[] str = br.readLine().trim().split(" ");
			map = new HashMap<Integer, Integer>();
			map.put(str[0].charAt(0) - '0', str[5].charAt(0) - '0');
			map.put(str[1].charAt(0) - '0', str[3].charAt(0) - '0');
			map.put(str[2].charAt(0) - '0', str[4].charAt(0) - '0');
			map.put(str[4].charAt(0) - '0', str[2].charAt(0) - '0');
			map.put(str[3].charAt(0) - '0', str[1].charAt(0) - '0');
			map.put(str[5].charAt(0) - '0', str[0].charAt(0) - '0');
			arr.add(map);
		}
		int result = Integer.MIN_VALUE;
		for (int i = 1; i < 7; i++) {
			result = Math.max(result, makeTop(i, n, arr));
		}
		System.out.println(result);
	}

	private static int makeTop(int key, int n, ArrayList<HashMap<Integer, Integer>> arr) {
		int sum = 0;
		int idx = 0;
		while (idx < n) {
			// i랑 map[i]를 뺀 가장 큰수 모두 더함.
			if ((key == 6 && arr.get(idx).get(key) == 5) || (key == 5 && arr.get(idx).get(key) == 6)) {
				sum += 4;
			} else if (key == 6 || arr.get(idx).get(key) == 6) {
				sum += 5;
			} else {
				sum += 6;
			}
			// 바닥 갱신!
			key = arr.get(idx).get(key);
			idx++;
		}
		return sum;
	}
}
