import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class hwalgo26 {

	static int n, w, h, answer;
	static int[] dr = { 0, -1, 0, 1 };
	static int[] dc = { -1, 0, 1, 0 };

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int testcase = Integer.parseInt(br.readLine().trim());
		for (int t = 1; t <= testcase; t++) {
			answer = Integer.MAX_VALUE;
			String[] input = br.readLine().trim().split(" ");
			n = Integer.parseInt(input[0]);
			w = Integer.parseInt(input[1]);
			h = Integer.parseInt(input[2]);
			int[][] map = new int[h][w];

			for (int i = 0; i < h; i++) {
				input = br.readLine().trim().split(" ");
				for (int j = 0; j < w; j++) {
					map[i][j] = Integer.parseInt(input[j]);
				}
			} // 입력끝

			for (int i = 0; i < w; i++) {
				int[][] copymap = makeCopy(map);
				permu(i, 0, copymap);
			}

			// 출력
			System.out.println("#" + t + " " + answer);
		}
	}

	private static void permu(int idx, int cnt, int[][] copymap) {
		if (cnt == n) {
			answer = Math.min(answer, count(copymap));
			return;
		}

		int[][] tmpMap = makeCopy(copymap);

		// idx열 반응시키기
		breakStone(idx, tmpMap);
		// map 정리하기
		cleanStone(tmpMap);

		for (int j = 0; j < w; j++) {
			permu(j, cnt + 1, tmpMap);
		}
	}

	private static void breakStone(int c, int[][] copymap) {
		int r = 0;
		while (copymap[r][c] == 0) {
			r++;
			if (isAliable(r, c)) {
				return;
			}
		}
		Queue<int[]> queue = new LinkedList<int[]>();
		queue.offer(new int[] { r, c, copymap[r][c] });

		while (!queue.isEmpty()) {
			int[] nowarr = queue.poll();
			int nowR = nowarr[0];
			int nowC = nowarr[1];
			int nowValue = nowarr[2];

			// now 적용
			copymap[nowR][nowC] = 0;
			// 확산
			if (nowValue != 1)
				for (int i = 0; i < 4; i++) {
					int tmpR = nowR;
					int tmpC = nowC;
					for (int j = 1; j < nowValue; j++) {
						tmpR += dr[i];
						tmpC += dc[i];
						if (isAliable(tmpR, tmpC))
							continue;
						if (copymap[tmpR][tmpC] == 0)
							continue;
						if (copymap[tmpR][tmpC] != 1) {
							queue.offer(new int[] { tmpR, tmpC, copymap[tmpR][tmpC] });
						}
						copymap[tmpR][tmpC] = 0;
					}
				}
		}
	}

	private static boolean isAliable(int tmpR, int tmpC) {
		return tmpR < 0 || tmpR > h - 1 || tmpC < 0 || tmpC > w - 1;
	}

	private static void cleanStone(int[][] copymap) {
		for (int c = 0; c < w; c++) {
			for (int r = h - 1; r >= 0; r--) {
				if (copymap[r][c] == 0) {
					int tmpR = -1;
					for (int i = r; i >= 0; i--) {
						if (copymap[i][c] != 0) {
							tmpR = i;
							break;
						}
					}
					if (tmpR != -1) {
						copymap[r][c] = copymap[tmpR][c];
						copymap[tmpR][c] = 0;
					} else {
						break;
					}
				}
			}
		}
	}

	private static int count(int[][] copymap) {
		int cnt = 0;
		for (int i = 0; i < h; i++) {
			for (int j = 0; j < w; j++) {
				if (copymap[i][j] != 0)
					cnt++;
			}
		}
		return cnt;
	}

	private static int[][] makeCopy(int[][] map) {
		int[][] copy = new int[h][w];
		for (int i = 0; i < h; i++) {
			System.arraycopy(map[i], 0, copy[i], 0, w);
		}
		return copy;
	}
}
