package com.ssafy.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class hwalgo11_����_7��_�ִ��� {

	static int[][] map;
	static StringBuilder sb;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine().trim());
		map = new int[n][n];
		for (int i = 0; i < n; i++) {
			char[] tmp = br.readLine().trim().toCharArray();
			for (int j = 0; j < n; j++) {
				map[i][j] = tmp[j] - '0';
			}
		}
		sb = new StringBuilder();
		quadrant(0, 0, n);
		System.out.println(sb.toString());
	}

	private static void quadrant(int dx, int dy, int n) {
		boolean flag = true;
		int check = map[dx][dy];
		if (n != 1)
			for (int i = dx; i < dx + n; i++) {
				for (int j = dy; j < dy + n; j++) {
					if (map[i][j] != check) {
						flag = false;
						break;
					}
				}
				if (!flag)
					break;
			}
		// ��ü�� ������ ��
		if (flag) {
			sb.append(check);
		} else {// �ٸ���
			sb.append("(");
			// ���
			quadrant(dx, dy, n / 2);
			quadrant(dx, dy + n / 2, n / 2);
			quadrant(dx + n / 2, dy, n / 2);
			quadrant(dx + n / 2, dy + n / 2, n / 2);
			sb.append(")");
		}
	}
}
