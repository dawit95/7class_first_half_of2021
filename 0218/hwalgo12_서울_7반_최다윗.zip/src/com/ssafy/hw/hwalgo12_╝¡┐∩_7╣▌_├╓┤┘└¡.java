package com.ssafy.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class hwalgo12_����_7��_�ִ��� {

	static char[][] map;
	static int result, r, c;
	static int[] dr = { 0, 1, 0, -1 };
	static int[] dc = { 1, 0, -1, 0 };

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine().trim(), " ");
		r = Integer.parseInt(st.nextToken());
		c = Integer.parseInt(st.nextToken());
		map = new char[r][c];
		for (int i = 0; i < r; i++) {
			map[i] = br.readLine().trim().toCharArray();
		}
		result = 1;
		moveToy(0, 0, 1, 1 << map[0][0] - 'A');
		System.out.println(result);
	}

	private static boolean moveToy(int dx, int dy, int score, int mask) {

		result = Math.max(result, score);
		if (score == 26)
			return true;
		for (int i = 0; i < 4; i++) {
			int x = dx + dr[i];
			int y = dy + dc[i];
			if (x < 0 || x > r - 1 || y < 0 || y > c - 1)
				continue;
			if ((mask & 1 << map[x][y] - 'A') != 0)
				continue;

			if (moveToy(x, y, score + 1, mask | 1 << map[x][y] - 'A'))
				return true;
		}
		return false;
	}
}
