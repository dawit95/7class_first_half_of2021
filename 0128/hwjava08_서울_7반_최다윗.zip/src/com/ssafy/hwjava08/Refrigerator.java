package com.ssafy.hwjava08;

public class Refrigerator extends Product {
	
	private int volume;

	public Refrigerator() {
		this(0,"냉장고 이름",0,0);
		this.volume = 0;
	}

	public Refrigerator(int serialNumber, String name, int price, int quantity) {
		super(serialNumber, name, price, quantity);
		this.volume = 0;
	}

	public Refrigerator(int serialNumber, String name, int price, int quantity, int volume) {
		super(serialNumber, name, price, quantity);
		this.volume = volume;
	}

	public int getVolume() {
		return volume;
	}

	@Override
	public String toString() {
		return "Refrigerator [getSerialNumber()=" + getSerialNumber() + ", getName()=" + getName() + ", getPrice()="
				+ getPrice() + "원, getQuantity()=" + getQuantity() + "개, volume=" + volume + "L]";
	}
	
	
	
}
