package com.ssafy.hwjava08;

import java.util.ArrayList;

import com.ssafy.hwjava08.exception.*;

public class ProductMgrImpl implements IProductMgr {

	private ArrayList<Product> products = new ArrayList<Product>();
	private static ProductMgrImpl instance;

	public static ProductMgrImpl getInstance() {
		if (instance == null) {
			instance = new ProductMgrImpl();
		}
		return instance;
	}

	@Override
	public void add(Product product) throws DuplicateException {

		for (Product product1 : products) {
			if (product1.getSerialNumber() == product.getSerialNumber())
				throw new DuplicateException("중복된 상품으로 저장할수 없습니다.");
		}
		products.add(product);
	}

	@Override
	public ArrayList<Product> list() {
		return products;
	}

	@Override
	public Product list(int serialNumber) throws CodeNotFoundException {
		for (Product product : products) {
			if (product.getSerialNumber() == serialNumber)
				return product;
		}
		throw new CodeNotFoundException("상품 번호가 존재하지 않습니다.");
	}

	@Override
	public ArrayList<Product> list(String subName) {
		String tmp = subName.trim();
		ArrayList<Product> result = new ArrayList<Product>();
		for (Product product : products) {
			if (product.getName().contains(tmp))
				result.add(product);
		}
		return result;
	}

	@Override
	public ArrayList<TV> TVList() {
		ArrayList<TV> tvs = new ArrayList<TV>();
		for (Product product : products) {
			if (product instanceof TV)
				tvs.add((TV) product);
		}
		return tvs;
	}

	@Override
	public ArrayList<TV> TVList(int inch) throws ProductNotFoundException {
		ArrayList<TV> tvs = new ArrayList<TV>();
		for (TV tv : this.TVList()) {
			if (tv.getInch() >= inch) {
				tvs.add(tv);
			}
		}
		if (tvs.isEmpty())
			throw new ProductNotFoundException("상품이 존재하지 않습니다.");
		return tvs;
	}

	@Override
	public ArrayList<Refrigerator> RefrigeratorList() {
		ArrayList<Refrigerator> refrigerators = new ArrayList<Refrigerator>();
		for (Product product : products) {
			if (product instanceof Refrigerator)
				refrigerators.add((Refrigerator) product);
		}
		return refrigerators;
	}

	@Override
	public ArrayList<Refrigerator> RefrigeratorList(int volume) throws ProductNotFoundException {
		ArrayList<Refrigerator> refrigerators = new ArrayList<Refrigerator>();
		for (Refrigerator refrigerator : this.RefrigeratorList()) {
			if (refrigerator.getVolume() >= volume)
				refrigerators.add(refrigerator);
		}
		if (refrigerators.isEmpty())
			throw new ProductNotFoundException("상품이 존재하지 않습니다.");
		return refrigerators;
	}

	@Override
	public boolean updatePrice(int serialNumber, int price) throws CodeNotFoundException {
		Product tmp = this.list(serialNumber);
		if (tmp != null) {
			tmp.setPrice(price);
			return true;
		} else
			return false;
	}

	@Override
	public boolean delete(int serialNumber) throws CodeNotFoundException {
		boolean result = products.remove(this.list(serialNumber));
		return result;
	}

	@Override
	public int totalPrice() {
		int total = 0;
		for (Product product : products) {
			total += product.getPrice();
		}
		return total;
	}

}
