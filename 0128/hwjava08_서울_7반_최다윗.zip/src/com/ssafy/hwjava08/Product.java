package com.ssafy.hwjava08;

public class Product {
	private int serialNumber;
	private String name;
	private int price;
	private int quantity;

	public Product() {
		super();
	}

	public Product(int serialNumber, String name, int price, int quantity) {
		super();
		this.serialNumber = serialNumber;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}

	public int getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Product [serialNumber=" + serialNumber + ", Name=" + name + ", price=" + price + "원, quantity="
				+ quantity + "개 ]";
	}

}
