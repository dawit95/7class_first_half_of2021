package com.ssafy.hwjava08;

import java.util.ArrayList;

import com.ssafy.hwjava08.exception.*;

public interface IProductMgr {

	// 상품정보 (TV 와 Refrigerator) 를 저장
	public void add(Product p) throws DuplicateException;

	// 상품정보 전체를 검색하는 기능
	public ArrayList<Product> list();

	// 상품번호로 상품을 검색하는 기능
	public Product list(int num) throws CodeNotFoundException;

	// 상품명으로 상품을 검색하는 기능 상품명 부분 검색 가능
	public ArrayList<Product> list(String subName);

	// TV 정보만 검색
	public ArrayList<TV> TVList();

	// 몇inch 이상 TV 검색
	public ArrayList<TV> TVList(int inch) throws ProductNotFoundException;

	// Refrigerator 정보만 검색
	public ArrayList<Refrigerator> RefrigeratorList();

	// 몇 L이상 Refrigerator 검색
	public ArrayList<Refrigerator> RefrigeratorList(int volume) throws ProductNotFoundException;

	// 상품번호와 가격을 입력 받아 상품 가격을 변경할 수 있는 기능
	public boolean updatePrice(int num, int price) throws CodeNotFoundException;

	// 상품번호로 상품을 삭제하는 기능
	public boolean delete(int num) throws CodeNotFoundException;

	// 전체 재고 상품 금액을 구하는 기능
	public int totalPrice();
}
