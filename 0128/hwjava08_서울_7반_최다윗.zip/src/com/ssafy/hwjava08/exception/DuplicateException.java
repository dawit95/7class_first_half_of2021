package com.ssafy.hwjava08.exception;

public class DuplicateException extends Exception {

	public DuplicateException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);

	}
}
