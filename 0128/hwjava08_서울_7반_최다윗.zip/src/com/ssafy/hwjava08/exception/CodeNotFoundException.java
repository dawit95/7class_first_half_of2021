package com.ssafy.hwjava08.exception;

public class CodeNotFoundException extends Exception {
	
	public CodeNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
