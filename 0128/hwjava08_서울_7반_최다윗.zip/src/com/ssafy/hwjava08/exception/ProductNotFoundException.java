package com.ssafy.hwjava08.exception;

public class ProductNotFoundException extends Exception {
	
	public ProductNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
