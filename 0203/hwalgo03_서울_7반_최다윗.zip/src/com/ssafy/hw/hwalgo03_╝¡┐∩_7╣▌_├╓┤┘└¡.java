package com.ssafy.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class hwalgo03_����_7��_�ִ��� {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.parseInt(br.readLine().trim());
		int shap = 0;
		while (shap++ < t) {
			StringTokenizer st = new StringTokenizer(br.readLine().trim(), " ");
			int n = Integer.parseInt(st.nextToken());
			int m = Integer.parseInt(st.nextToken());
			int[][] pari = new int[n][n];
			for (int i = 0; i < n; i++) {
				st = new StringTokenizer(br.readLine().trim(), " ");
				for (int j = 0; j < n; j++) {
					pari[i][j] = Integer.parseInt(st.nextToken());
				}
			}

			int tmpSum = 0;
			int result = 0;
			for (int i = 0; i <= n - m; i++) {
				for (int j = 0; j <= n - m; j++) {
					for (int x = 0; x < m; x++)
						for (int y = 0; y < m; y++)
							tmpSum += pari[i + x][j + y];

					result = Math.max(result, tmpSum);
					tmpSum = 0;
				}
			}
			System.out.println(shap + " " + result);
		} // while end!!
	}
}
