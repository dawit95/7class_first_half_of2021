package com.ssafy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class hwalgo01_1244 {

	private static int[] arr;

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int switchCount = Integer.parseInt(br.readLine());
		arr = new int[switchCount];
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");
		for (int i = 0; i < switchCount; i++) {
			arr[i] = Integer.parseInt(st.nextToken());
		}

		int n = Integer.parseInt(br.readLine());
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine(), " ");
			if (st.nextToken().equals("1")) {
				man(Integer.parseInt(st.nextToken()));
			} else {
				int num = Integer.parseInt(st.nextToken()) - 1;
				arr[num] = arr[num] == 0 ? 1 : 0;
				woman(num, 1);
			}
		}

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < arr.length; i++) {
			if (i % 20 == 0 && i != 0)
				sb.append("\n");
			sb.append(arr[i]);
			sb.append(" ");
		}
		System.out.println(sb.toString());
		br.close();

	}

	private static void man(int num) {
		for (int i = num - 1; i < arr.length; i += num) {
			arr[i] = arr[i] == 0 ? 1 : 0;
		}
		return;
	}

	private static void woman(int num, int plus) {
		if ((num - plus) < 0 || (num + plus) > arr.length - 1) {
			return;
		}
		if (arr[num + plus] == arr[num - plus]) {
			arr[num + plus] = arr[num + plus] == 0 ? 1 : 0;
			arr[num - plus] = arr[num - plus] == 0 ? 1 : 0;
			woman(num, plus + 1);
		} else {
			return;
		}
	}

}
