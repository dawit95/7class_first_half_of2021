export default {
  template: `
    <div>
      <h2 align="center">사원 정보</h2>
      <table class="table table-hover table-bordered">
        <thead class="thead-dark">
          <tr>
            <th class="text-center">사원 아이디</th>
            <th class="text-center">사원명</th>
            <th class="text-center">부서</th>
            <th class="text-center">직책</th>
            <th class="text-center">연봉</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="emp in emps" v-if="emp.id == param">
            <td class="text-center">{{emp.id}}</td>
            <td class="text-center">{{emp.name}}</td>
            <td class="text-center">{{emp.deptName}}</td>
            <td class="text-center">{{emp.title}}</td>
            <td class="text-center">{{emp.salary}}</td>
          </tr>
        </tbody>
      </table>
    </div>
    `,
  data() {
    return {
      param: '',
      emps: [],
    };
  },
  created() {
    const params = new URL(document.location).searchParams;
    alert(params.get('empid'));
    this.param = params.get('empid');

    this.emps = [];
    let temp = JSON.parse(localStorage.getItem('empList'));
    for (let idx = 0; idx < temp.length; idx++) {
      if (temp[idx].id == this.param) {
        this.emps.push(temp[idx]);
      }
    }
  },
};
