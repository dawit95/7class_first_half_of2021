export default {
  template: `
    <div>
      <h2 align="center">사원목록</h2>
      <div class="container text-center mb-2 p-2">
        <label for="searchword" >사원명 검색</label>
        <input id="searchword" type="text" v-model="searchTitle" /><button @click="search">검색</button>
      </div>
      <table class="table table-hover table-bordered">
          <thead class="thead-dark">
          <tr>
              <th class="text-center">사원 아이디</th>
              <th class="text-center">사원명</th>
              <th class="text-center">부서</th>
              <th class="text-center">직책</th>
              <th class="text-center">연봉</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="emp in emps" @click="goDetail(emp.id)">
              <td class="text-center">{{emp.id}}</td>
              <td class="text-center">{{emp.name}}</td>
              <td class="text-center">{{emp.dept}}</td>
              <td class="text-center">{{emp.title}}</td>
              <td class="text-center">{{emp.salary}}</td>
          </tr>
          </tbody>
      </table>
    </div>
    `,
  data() {
    return {
      searchTitle: '',
      emps: [],
    };
  },
  methods: {
    goDetail(empid) {
      location.href = 'hrm_detail.html?empid=' + empid;
    },
    search() {
      if (this.searchTitle == '') {
        console.log('로컬이 없음');
        this.emps = JSON.parse(localStorage.getItem('empList'));
      } else {
        console.log('로컬이 있음');
        this.emps = [];
        let temp = JSON.parse(localStorage.getItem('empList'));
        for (let idx = 0; idx < temp.length; idx++) {
          console.log('temp하나씩 보기' + temp[idx].name);
          if (temp[idx].name == this.searchTitle) {
            this.emps.push(temp[idx]);
          }
        }
      }
    },
  },
  created() {
    if (localStorage.getItem('empList')) {
      this.emps = JSON.parse(localStorage.getItem('empList'));
    }
  },
};
