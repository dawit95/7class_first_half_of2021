package com.ssafy.hw;

import java.util.LinkedList;

public class ��ɰ�� {

	public static void main(String[] args) {
		
	}
}

class Solution {
    public int[] solution(int[] progresses, int[] speeds) {
        int[] answer = {};
        int days =0;
		int count=0;
		int tmp =days;
		LinkedList<Integer> qu = new LinkedList<Integer>();
		
		for(int i=0; i<progresses.length; i++) {
			while(progresses[i]+(days*speeds[i])<100) {
				days++;
			}
			if(tmp != days) {
				tmp = days;
				qu.add(count);
				count=1;
			}else {
				count++;
			}
		}
		qu.add(count);
		qu.poll();
		answer = qu.stream().mapToInt(Integer::intValue).toArray();

        return answer;
    }
}
