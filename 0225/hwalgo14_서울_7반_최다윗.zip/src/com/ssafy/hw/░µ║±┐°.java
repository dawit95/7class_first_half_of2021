package com.ssafy.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ���� {
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int c = Integer.parseInt(st.nextToken());
		int r = Integer.parseInt(st.nextToken());
		int S = Integer.parseInt(br.readLine());
		int sz = 2 * (c + r);
		int[] arr = new int[S + 1];
		for (int i = 0; i <= S; i++) {
			st = new StringTokenizer(br.readLine());
			int dir = Integer.parseInt(st.nextToken());
			int pos = Integer.parseInt(st.nextToken());
			if (dir == 1)
				arr[i] = pos;
			else if (dir == 4)
				arr[i] = pos + c;
			else if (dir == 2)
				arr[i] = sz - r - pos;
			else
				arr[i] = sz - pos;
		}
		int ans = 0;
		for (int i = 0; i < S; i++)
			ans += Math.min(Math.abs(arr[S] - arr[i]), sz - Math.abs(arr[S] - arr[i]));
		System.out.println(ans);
	}
}
