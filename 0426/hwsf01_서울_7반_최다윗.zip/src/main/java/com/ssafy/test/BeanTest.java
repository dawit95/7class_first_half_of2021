package com.ssafy.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

public class BeanTest {

	public static void main(String[] args) throws IOException {
		ApplicationContext context = new ClassPathXmlApplicationContext("/applicationContext.xml");

		ProductService productService = context.getBean("pService", ProductServiceImpl.class);

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		Product product = new Product();
		System.out.print("상품 ID : ");
		product.setId(in.readLine());
		System.out.print("상품명 : ");
		product.setName(in.readLine());
		System.out.print("가격 : ");
		product.setPrice(Integer.parseInt(in.readLine()));
		System.out.print("설명 : ");
		product.setDescription(in.readLine());

		try {
			productService.insert(product);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("================================== 글목록 ================================== ");
		System.out.println("상품id\t제품명\t가격\t\t\t내용");
		System.out.println("----------------------------------------------------------------");
		try {
			List<Product> list = productService.selectAll();
			for (Product product1 : list) {
				System.out.println(product1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
