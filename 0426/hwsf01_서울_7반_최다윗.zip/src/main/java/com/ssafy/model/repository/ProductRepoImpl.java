package com.ssafy.model.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Product;
import com.ssafy.util.AutoCloseableUtil;

@Repository
public class ProductRepoImpl implements ProductRepo {

	@Autowired
	private DataSource dataSource;

	@Override
	public List<Product> selectAll() throws SQLException {
		List<Product> list = new ArrayList<Product>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = dataSource.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * \n");
			sql.append("from product");
			pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setId(rs.getString("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));

				list.add(product);
			}
		} finally {
			AutoCloseableUtil.close(rs, pstmt, conn);
		}

		return list;
	}

	@Override
	public Product select(String id) throws SQLException {
		Product product = null;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = dataSource.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * \n");
			sql.append("from product \n");
			sql.append("where id = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				product =  new Product();
				product.setId(rs.getString("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));
			}
		} finally {
			AutoCloseableUtil.close(rs, pstmt, conn);
		}
		return null;
	}

	@Override
	public int insert(Product product) throws SQLException {
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into product(id, name, price, description) \n");
			sql.append("values (?, ?, ?, ?)");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, product.getId());
			pstmt.setString(2, product.getName());
			pstmt.setInt(3, product.getPrice());
			pstmt.setString(4, product.getDescription());
			cnt = pstmt.executeUpdate();
		} finally {
			AutoCloseableUtil.close(pstmt, conn);
		}
		return cnt;
	}

	@Override
	public int update(Product product) throws SQLException {
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("update product \n");
			sql.append("set name = ?, price = ?, description = ? \n");
			sql.append("where id = ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, product.getName());
			pstmt.setInt(2, product.getPrice());
			pstmt.setString(3, product.getDescription());
			pstmt.setString(4, product.getId());
			cnt = pstmt.executeUpdate();
		} finally {
			AutoCloseableUtil.close(pstmt, conn);
		}
		return cnt;
	}

	@Override
	public int delete(String id) throws SQLException {
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("delete from product \n");
			insertMember.append("where id = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, id);
			cnt = pstmt.executeUpdate();
		} finally {
			AutoCloseableUtil.close(pstmt, conn);
		}
		return cnt;
	}

}
