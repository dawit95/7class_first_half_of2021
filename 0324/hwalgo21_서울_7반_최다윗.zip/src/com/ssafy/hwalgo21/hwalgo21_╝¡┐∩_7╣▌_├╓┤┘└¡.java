package com.ssafy.hwalgo21;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class hwalgo21_서울_7반_최다윗 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringBuilder sb = new StringBuilder();
		int t = Integer.parseInt(br.readLine().trim());
		int shap = 0;
		while (shap++ < t) {
			sb.append("#").append(shap).append(" ");
			int v = Integer.parseInt(br.readLine().trim());
			double[][] arr = new double[v][2];
			for (int i = 0; i < 2; i++) {
				StringTokenizer st = new StringTokenizer(br.readLine().trim(), " ");
				for (int j = 0; j < v; j++) {
					arr[j][i] = Double.parseDouble(st.nextToken());
				}
			}
			double tax = Double.parseDouble(br.readLine().trim());
			// 입력끝

			// prim
			double[] minEdge = new double[v];
			Arrays.fill(minEdge, Double.MAX_VALUE);
			boolean[] visited = new boolean[v];
			minEdge[0] = 0;
			double result = 0;

			for (int c = 0; c < v; c++) {

				double min = Double.MAX_VALUE;
				int minVertex = 0;
				// 신장트리에 연결되지 않은 정점중 minEdge비용이 최소인 정점.
				for (int i = 0; i < v; i++) {
					// 아직 신장트리에 없고 가장 최소정점을 보요하는 정점을 찾는중.
					if (!visited[i] && min > minEdge[i]) {
						min = minEdge[i];
						minVertex = i;
					}
				}

				result += tax * min;
				visited[minVertex] = true;

				double xLen = arr[minVertex][0];
				double yLen = arr[minVertex][1];
				for (int i = 0; i < v; i++) {
					// 아직 신장에 없고 나와 연결되어있는 아이들 중에 edge의 길이가 나랑 더 짧으면 update
					double x = Math.abs(xLen - arr[i][0]);
					double y = Math.abs(yLen - arr[i][1]);
					double edge = x * x + y * y;
					if (!visited[i] && minEdge[i] > edge) {
						minEdge[i] = edge;
					}
				}
			}
			sb.append(Math.round(result)).append("\n");
		}
		System.out.println(sb.toString());
	}
}
