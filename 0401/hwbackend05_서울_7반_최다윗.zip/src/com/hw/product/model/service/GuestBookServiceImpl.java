package com.hw.product.model.service;

import java.util.List;

import com.hw.product.model.GuestBookDto;
import com.hw.product.model.dao.GuestBookDaoImpl;

public class GuestBookServiceImpl implements GuestBookService {

	private static GuestBookServiceImpl guestBookServiceImpl;

	private GuestBookServiceImpl() {
	}

	public static GuestBookServiceImpl getGuestBookServiceImpl() {
		if (guestBookServiceImpl == null)
			guestBookServiceImpl = new GuestBookServiceImpl();
		return guestBookServiceImpl;
	}

	@Override
	public void registerArticle(GuestBookDto guestBookDto) throws Exception {
		GuestBookDaoImpl.getGuestBookDaoImpl().registerArticle(guestBookDto);
	}

	@Override
	public List<GuestBookDto> listArticle(String key, String word) throws Exception {
		return null;
	}

	@Override
	public GuestBookDto getArticle(int articleNo) throws Exception {
		return null;
	}

	@Override
	public void modifyArticle(GuestBookDto guestBookDto) throws Exception {
	}

	@Override
	public void deleteArticle(int articleNo) throws Exception {
	}

}
