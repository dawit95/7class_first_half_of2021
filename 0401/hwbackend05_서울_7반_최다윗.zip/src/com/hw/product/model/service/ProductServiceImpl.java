package com.hw.product.model.service;

import java.util.List;

import com.hw.product.model.ProductDto;
import com.hw.product.model.dao.ProductDao;
import com.hw.product.model.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService {

	private static ProductServiceImpl productServiceImpl;
	
	private ProductServiceImpl() {
	}
	
	public static ProductServiceImpl getProductServiceImpl() {
		if(productServiceImpl == null)
			productServiceImpl = new ProductServiceImpl();
		return productServiceImpl;
	}
	
	@Override
	public void registerProduct(ProductDto productDto) throws Exception {
		if(productDto.getName() == null || productDto.getContext() == null) {
			throw new Exception();
		}
		ProductDaoImpl.getProductDaoImpl().registerProduct(productDto);
	}

	@Override
	public List<ProductDto> listProduct(String key, String word) throws Exception {
		key = key == null ? "" : key;
		word = word == null ? "" : word;
		return ProductDaoImpl.getProductDaoImpl().listProduct(key, word);
	}

	@Override
	public ProductDto getProduct(int productno) throws Exception {
		return ProductDaoImpl.getProductDaoImpl().getProduct(productno);
	}

	@Override
	public void modifyProduct(ProductDto productDto) throws Exception {
		ProductDaoImpl.getProductDaoImpl().modifyProduct(productDto);
	}

	@Override
	public void deleteProduct(int productno) throws Exception {
		ProductDaoImpl.getProductDaoImpl().deleteProduct(productno);
	}

}
