package com.hw.product.model.service;

import com.hw.product.model.MemberDto;
import com.hw.product.model.dao.MemberDaoImpl;

/*
 * 한개만 존재해야 하는 class singleton pattern을 적용한다.
 */
public class MemberServiceImpl implements MemberService {

	private static MemberService memberService;
	
	public static MemberService getMemberService() {
		if(memberService == null)
			memberService = new MemberServiceImpl();
		return memberService;
	}

	private MemberServiceImpl() {
	}
	
	@Override
	public void registerMember(MemberDto memberDto) throws Exception {
	}

	@Override
	public MemberDto login(String userId, String userPwd) throws Exception {
//		유효성 검사 필수
		
		return MemberDaoImpl.getMemberDao().login(userId, userPwd);
	}

	@Override
	public MemberDto getMember(String userId) throws Exception {
		return null;
	}

	@Override
	public void modifyMember(MemberDto memberDto) throws Exception {
	}

	@Override
	public void deleteMember(String userId) throws Exception {
	}

}
