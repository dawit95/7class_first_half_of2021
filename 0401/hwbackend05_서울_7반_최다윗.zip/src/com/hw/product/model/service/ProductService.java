package com.hw.product.model.service;

import java.util.List;

import com.hw.product.model.ProductDto;

public interface ProductService {

//	글작성
	void registerProduct(ProductDto productDto) throws Exception;

//	글목록 (페이지 번호를 가져가야함, 무엇으로 검색, 검색키워드)
	List<ProductDto> listProduct(String key, String word) throws Exception;

//	글수정을 위한 글얻기
	ProductDto getProduct(int productno) throws Exception;

//	글수정
	void modifyProduct(ProductDto productDto) throws Exception;

//	글삭제
	void deleteProduct(int productno) throws Exception;

}
