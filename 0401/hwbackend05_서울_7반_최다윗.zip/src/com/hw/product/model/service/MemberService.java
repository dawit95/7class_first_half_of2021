package com.hw.product.model.service;

import com.hw.product.model.MemberDto;

public interface MemberService {

//	회원가입 (DB에 넣는 것이 목적)
	void registerMember(MemberDto memberDto) throws Exception;

//	로그인 (처리시 MemberDto가 있냐 없냐)
	MemberDto login(String userId, String userPwd) throws Exception;

//	여기부터 로그인 후 사용 가능
//	회원정보 수정을 위한 회원의 모든 정보 얻기
	MemberDto getMember(String userId) throws Exception;

//	회원정보 수정
	void modifyMember(MemberDto memberDto) throws Exception;

//	회원탈퇴
	void deleteMember(String userId) throws Exception;

}
