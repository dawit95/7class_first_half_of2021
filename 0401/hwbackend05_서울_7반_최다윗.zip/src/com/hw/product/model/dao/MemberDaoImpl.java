package com.hw.product.model.dao;

import java.sql.*;

import com.hw.product.model.MemberDto;
import com.ssafy.util.DBUtil;

public class MemberDaoImpl implements MemberDao {

	private static MemberDao memberDao;

	private MemberDaoImpl() {
	}

	public static MemberDao getMemberDao() {
		if (memberDao == null)
			memberDao = new MemberDaoImpl();
		return memberDao;
	}

	@Override
	public void registerMember(MemberDto memberDto) throws SQLException {
	}

	@Override
	public MemberDto login(String userId, String userPwd) throws SQLException {
		MemberDto memberDto = null;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnect();
			String sql = "select username, email \n";
			sql += "from ssafy_member \n";
			sql += "where userid = ? and userpwd = ?";
			pstmt = conn.prepareStatement(sql);
			int idx = 0;
			pstmt.setString(++idx, userId);
			pstmt.setString(++idx, userPwd);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				memberDto = new MemberDto();
				memberDto.setUserName(rs.getString("username"));
				memberDto.setUserId(userId);
				memberDto.setEmail(rs.getString("email"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}

		return memberDto;
	}

	@Override
	public MemberDto getMember(String userId) throws SQLException {
		return null;
	}

	@Override
	public void modifyMember(MemberDto memberDto) throws SQLException {
	}

	@Override
	public void deleteMember(String userId) throws SQLException {
	}

}
