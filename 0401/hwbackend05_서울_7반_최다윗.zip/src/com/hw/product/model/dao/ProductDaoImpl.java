package com.hw.product.model.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.hw.product.model.ProductDto;
import com.ssafy.util.DBUtil;

public class ProductDaoImpl implements ProductDao {

	private static ProductDaoImpl productDaoImpl;

	private ProductDaoImpl() {
	}

	public static ProductDaoImpl getProductDaoImpl() {
		if (productDaoImpl == null)
			productDaoImpl = new ProductDaoImpl();
		return productDaoImpl;
	}

	@Override
	public void registerProduct(ProductDto poductDto) throws SQLException {

		System.out.println(" DAO 내부");
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnect();
			StringBuilder insertArticle = new StringBuilder();
			insertArticle
					.append("insert into hw_product (userid, productname, productprice, content, regtime) \n");
			insertArticle.append("values (?, ?, ?, ?, now())");
			pstmt = conn.prepareStatement(insertArticle.toString());
			int idx = 0;
			pstmt.setString(++idx, poductDto.getUserId());
			pstmt.setString(++idx, poductDto.getName());
			pstmt.setString(++idx, poductDto.getPrice());
			pstmt.setString(++idx, poductDto.getContext());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt, conn);
		}
	}

	@Override
	public List<ProductDto> listProduct(String key, String word) throws SQLException {
		List<ProductDto> list = new ArrayList<ProductDto>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnect();
			StringBuilder sql = new StringBuilder();
			sql.append("select productno, userid, productname, productprice, content, regtime \n");
			sql.append("from hw_product \n");
			if (!word.isEmpty()) {
				if ("subject".equals(key)) {
					sql.append("where productname like ? \n");
				} else {
					// 컬럼값은 ? 변수로 쓰지 못함.
					sql.append("where " + key + " = ? \n");
				}
			}
			sql.append("order by productno desc \n");
			pstmt = conn.prepareStatement(sql.toString());
			if (!word.isEmpty()) {
				if ("subject".equals(key))
					// %는 몇개가 오든 상관없는 와일드 카드 _는 _의 숫자만큼 아무거나 오는것.

					pstmt.setString(1, "%" + word + "%");
				else
					pstmt.setString(1, word);
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProductDto productDto = new ProductDto();
				productDto.setProductno(rs.getInt("productno"));
				productDto.setUserId(rs.getString("userid"));
				productDto.setName(rs.getString("productname"));
				productDto.setPrice(rs.getString("productprice"));
				productDto.setContext(rs.getString("content"));
				productDto.setJoindate(rs.getString("regtime"));

				list.add(productDto);
			}
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}

		return list;
	}

	@Override
	public ProductDto getProduct(int productno) throws SQLException {
		ProductDto productDto = null;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnect();
			StringBuilder sql = new StringBuilder();
			sql.append("select * \n");
			sql.append("from hw_product \n");
			sql.append("where productno = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, productno);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				productDto = new ProductDto();
				productDto.setProductno(rs.getInt("productno"));
				productDto.setName(rs.getString("productname"));
				productDto.setPrice(rs.getString("productprice"));
				productDto.setContext(rs.getString("content"));
				productDto.setJoindate(rs.getString("regtime"));
			}
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}
		return productDto;
	}

	@Override
	public void modifyProduct(ProductDto poductDto) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnect();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("update hw_product \n");
			insertMember.append("set productname = ?,  productprice = ?, content = ? \n");
			insertMember.append("where productno = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, poductDto.getName());
			pstmt.setString(2, poductDto.getName());
			pstmt.setString(3, poductDto.getContext());
			pstmt.setInt(4, poductDto.getProductno());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt, conn);
		}
	}

	@Override
	public void deleteProduct(int productno) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnect();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("delete from hw_product \n");
			insertMember.append("where productno = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setInt(1, productno);
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt, conn);
		}
	}

}
