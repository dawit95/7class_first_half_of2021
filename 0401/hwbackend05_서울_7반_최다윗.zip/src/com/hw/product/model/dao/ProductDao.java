package com.hw.product.model.dao;

import java.sql.SQLException;
import java.util.List;

import com.hw.product.model.GuestBookDto;
import com.hw.product.model.ProductDto;

public interface ProductDao {

// 	상품 등록
	void registerProduct(ProductDto poductDto) throws SQLException;

//	글목록 (페이지 번호를 가져가야함, 무엇으로 검색, 검색키워드)
	List<ProductDto> listProduct(String key, String word) throws SQLException;

//	글수정을 위한 글얻기
	ProductDto getProduct(int productno) throws SQLException;

//	글수정
	void modifyProduct(ProductDto poductDto) throws SQLException;

//	글삭제
	void deleteProduct(int productno) throws SQLException;

}
