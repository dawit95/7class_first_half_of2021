package com.hw.product.model.dao;

import java.sql.*;
import java.util.List;

import com.hw.product.model.GuestBookDto;
import com.ssafy.util.DBUtil;

public class GuestBookDaoImpl implements GuestBookDao {

	private static GuestBookDaoImpl guestBookDaoImpl;

	private GuestBookDaoImpl() {
	}

	public static GuestBookDaoImpl getGuestBookDaoImpl() throws SQLException {
		if (guestBookDaoImpl == null)
			guestBookDaoImpl = new GuestBookDaoImpl();
		return guestBookDaoImpl;
	}

	@Override
	public void registerArticle(GuestBookDto guestBookDto) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnect();
			StringBuilder insertArticle = new StringBuilder();
			insertArticle.append("insert into guestbook (userid, subject, content, regtime) \n");
			insertArticle.append("values (?, ?, ?, now())");
			pstmt = conn.prepareStatement(insertArticle.toString());
			int idx = 0;
			pstmt.setString(++idx, guestBookDto.getUserId());
			pstmt.setString(++idx, guestBookDto.getSubject());
			pstmt.setString(++idx, guestBookDto.getContent());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt, conn);
		}
	}

	@Override
	public List<GuestBookDto> listArticle(String key, String word) throws SQLException {
		return null;
	}

	@Override
	public GuestBookDto getArticle(int articleNo) throws SQLException {
		return null;
	}

	@Override
	public void modifyArticle(GuestBookDto guestBookDto) throws SQLException {
	}

	@Override
	public void deleteArticle(int articleNo) throws SQLException {
	}

}
