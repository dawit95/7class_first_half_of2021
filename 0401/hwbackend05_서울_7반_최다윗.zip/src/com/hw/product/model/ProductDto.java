package com.hw.product.model;

public class ProductDto {

	private int productno;
	private String userId;
	private String name;
	private String price;
	private String context;
	private String joindate;
	

	public String getJoindate() {
		return joindate;
	}

	public void setJoindate(String joindate) {
		this.joindate = joindate;
	}

	public ProductDto(String userId, String name, String price, String context) {
		super();
		this.userId = userId;
		this.name = name;
		this.price = price;
		this.context = context;
	}

	public ProductDto() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getContext() {
		return context;
	}

	public int getProductno() {
		return productno;
	}

	public void setProductno(int productno) {
		this.productno = productno;
	}

	public void setContext(String context) {
		this.context = context;
	}

	@Override
	public String toString() {
		return "상품넘버:"+productno + " 상품:" + name + " 가격:" + price + " 설명:" + context;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	
	
}
