package com.hw.product.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.hw.product.model.MemberDto;
import com.hw.product.model.ProductDto;
import com.hw.product.model.service.MemberServiceImpl;
import com.hw.product.model.service.ProductServiceImpl;

/*
 * 어떤 jsp로 움직일지 어떤BL를 요청할지 결정하는 controller
 */

@WebServlet("/main")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String root = request.getContextPath();
		String act = request.getParameter("act");
		System.out.println(act);
		if("mvlogin".equals(act)) {
			response.sendRedirect(root + "/user/login.jsp");
		} else if("mvjoin".equals(act)) {
			response.sendRedirect(root + "/user/join.jsp");
		} else if("login".equals(act)) {
			login(request, response);
		} else if("logout".equals(act)) {
			logout(request, response);
		} else if("mvwrite".equals(act)) {
			response.sendRedirect(root + "/view/write.jsp");
		} else if("write".equals(act)) {
			registerProduct(request, response);
		} else if("list".equals(act)) {
			listProduct(request, response);
		} else if("mvmodify".equals(act)) {
			moveModifyProduct(request, response);
		} else if("modify".equals(act)) {
			modifyProduct(request, response);
		} else if("delete".equals(act)) {
			deleteProduct(request, response);
		} else {
			response.sendRedirect(root);
		}

	}

	private void deleteProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		int productno = Integer.parseInt(request.getParameter("productno"));
		
		try {
			ProductServiceImpl.getProductServiceImpl().deleteProduct(productno);
			path = "/main?act=list&key=&word=";
			response.sendRedirect(request.getContextPath() + path);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "상품 삭제 처리 중 문제가 발생했습니다.");
			path = "/error/error500.jsp";
			request.getRequestDispatcher(path).forward(request, response);
		}
	}

	private void modifyProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		ProductDto productDto = new ProductDto();
		productDto.setProductno(Integer.parseInt(request.getParameter("productno")));
		productDto.setName(request.getParameter("productname"));
		productDto.setPrice(request.getParameter("productprice"));
		productDto.setContext(request.getParameter("content"));
		
		try {
			ProductServiceImpl.getProductServiceImpl().modifyProduct(productDto);
			path = "/main?act=list&key=&word=";
			response.sendRedirect(request.getContextPath() + path);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "상품 수정 중에 문제가 발생했습니다.");
			path = "/error/error500.jsp";
			request.getRequestDispatcher(path).forward(request, response);
		}
	}

	private void moveModifyProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		int productno = Integer.parseInt(request.getParameter("productno"));
		
		try {
			ProductDto productDto = ProductServiceImpl.getProductServiceImpl().getProduct(productno);
			request.setAttribute("product", productDto);
			path = "/view/modify.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "상품 수정 처리 중 문제가 발생했습니다.");
			path = "/error/error500.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void listProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String key = request.getParameter("key");
		String word = request.getParameter("word");
		try {
			List<ProductDto> list = ProductServiceImpl.getProductServiceImpl().listProduct(key, word);
			request.setAttribute("products", list);
			path = "/view/list.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글목록을 얻어오는 중 문제가 발생했습니다.");
			path = "/error/error500.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void registerProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "/index.jsp";
		HttpSession session = request.getSession();
		MemberDto memberDto = (MemberDto) session.getAttribute("userinfo");

		if (memberDto != null) {
			System.out.println("memberDto ok!");
			ProductDto productDto = new ProductDto();
			productDto.setUserId(memberDto.getUserId());
			productDto.setName(request.getParameter("productName"));
			productDto.setPrice(request.getParameter("productPrice"));
			productDto.setContext(request.getParameter("productDescription"));

			try {
				ProductServiceImpl.getProductServiceImpl().registerProduct(productDto);
				path = "/view/writesuccess.jsp";
				System.out.println("Service ok!");
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "상품등록 중 문제가 발생했습니다.");
				path = "/error/error500.jsp";
			}
		} else {
			request.setAttribute("msg", "로그인 후 사용가능한 서비스입니다.");
			path = "/error/error500.jsp";
		}
		// 내 경로 안에서 이동할수 있음.
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		session.invalidate();

		response.sendRedirect(request.getContextPath());
	}

	private void login(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String root = request.getContextPath();
		String path = "/index.jsp";

		String userId = request.getParameter("userid");
		String userPwd = request.getParameter("userpwd");

		MemberDto memberDto = null;
		try {
			memberDto = MemberServiceImpl.getMemberService().login(userId, userPwd);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (memberDto != null) { // 성공
//			session setting
			HttpSession session = request.getSession();
			session.setAttribute("userinfo", memberDto);
//			request.setAttribute("userinfo", memberDto);
//			response.sendRedirect(root + "/index.jsp");

//			Cookie setting
			String idsv = request.getParameter("idsave");
			if (idsv != null) {
				Cookie cookie = new Cookie("save_id", userId);
				cookie.setPath(root);
				// 60초*60분*24시간*365일*40년 초단위
				cookie.setMaxAge(60 * 60 * 24 * 5);

				// 서버에서 만든 쿠키를 client에게 전해주기
				response.addCookie(cookie);
			} else { // id save X
				Cookie cookies[] = request.getCookies();
				if (cookies != null) {
					for (Cookie cookie : cookies) {
						if (cookie.getName().equals("save_id")) {
							cookie.setMaxAge(0);
							response.addCookie(cookie);
							break;
						}
					}
				}
			}

		} else { // 실패
			request.setAttribute("msg", "가입하지 않은 아이디이거나, 잘못된 비밀번호입니다.");
			path = "/error/error500.jsp";
//			response.sendRedirect(root + "/user/login.jsp");
		}

		// 내 경로 안에서 이동할수 있음.
		RequestDispatcher disp = request.getRequestDispatcher(path);
		disp.forward(request, response);

	}

}
