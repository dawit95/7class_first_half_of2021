package com.ssafy.hw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Snail {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.parseInt(br.readLine());
		int shap = 0;

		while (shap++ < t) {
			int n = Integer.parseInt(br.readLine());
			int[][] arr = new int[n][n];
			
			int num = 1;
			int dx = 0;
			int dy = 0;
			int rot = 1;

			while (n > 0) {

				for (int z = 0; z < n; z++) {
					arr[dx][dy] = num++;
					dy += rot;
				}
				dy -= rot;
				n--;
				dx += rot;

				for (int z = 0; z < n; z++) {
					arr[dx][dy] = num++;
					dx += rot;
				}
				dx -= rot;
				rot *= -1;
				dy += rot;

			}
			//���
			StringBuilder sb = new StringBuilder();
			sb.append("#").append(shap).append(" \n");
			for (int i = 0; i < arr.length; i++) {
				for (int j = 0; j < arr.length; j++) {
					sb.append(arr[i][j]);
					sb.append(" ");
				}
				sb.append("\n");
			}
			sb.setLength(sb.length()-1);
			System.out.println(sb.toString());
		}

	}

}
