package com.ssafy.hwalgo22;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class hwalgo22_서울_7반_최다윗 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.parseInt(br.readLine().trim());
		int shap = 0;
		while (shap++ < t) {
			int n = Integer.parseInt(br.readLine().trim());
			n+=2;
			int[][] arr = new int[n][2];

			for (int i = 0; i < n; i++) {
				String[] str = br.readLine().trim().split(" ");
				arr[i][0] = Integer.parseInt(str[0]);
				arr[i][1] = Integer.parseInt(str[1]);
			}
			// 입력끝
			int end = n-1;
			// 정답 배열
			int[] distance = new int[n];
			// 하나씩 확인하고 다시 않하기 위해 불린
			boolean[] visited = new boolean[n];

			Arrays.fill(distance, Integer.MAX_VALUE);
			distance[0] = 0;

			for (int i = 0; i < n; i++) {
				int min = Integer.MAX_VALUE;
				int current = 0; // min 최소비용에 해당하는 정점번호.
				// step 1. : 처리하지 않은 정점중에 출발지에서 가장 가까운(최소비용) 정점 선택
				for (int j = 0; j < n; j++) {
					if (!visited[j] && min > distance[j]) {
						min = distance[j];
						current = j;
					}
				}
				visited[current] = true;
				if(current == end) break;

				// step 2. : 선택된 current를 경유지로 하여 아직 처리하지 않은 다른 정점으로의 최소 비용 따져본다.
				for (int j = 0; j < n; j++) {
					int nowDistance = Math.abs(arr[current][0]-arr[j][0]) +Math.abs(arr[current][1]-arr[j][1]);
					if (!visited[j]&& nowDistance<=1000 && distance[j] > min + nowDistance) {
						distance[j] = min + nowDistance;
					}
				}
			}
			System.out.println(distance[end] == Integer.MAX_VALUE?"sad":"happy");
		}
	}
}
